<?php
if (!defined('ABSPATH')) exit; // Exit if accessed directly

// Enqueue styles and scripts
function verma_packers_scripts() {
    wp_enqueue_style('verma-packers-style', get_stylesheet_uri());
    wp_enqueue_script('verma-packers-script', get_template_directory_uri() . '/js/main.js', array(), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'verma_packers_scripts');

// Add theme support
function verma_packers_theme_support() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('elementor');
}
add_action('after_setup_theme', 'verma_packers_theme_support');

// Register Elementor widgets
function verma_packers_register_elementor_widgets($widgets_manager) {
    require_once(__DIR__ . '/widgets/hero-widget.php');
    $widgets_manager->register(new \Verma_Packers_Hero_Widget());
}
add_action('elementor/widgets/register', 'verma_packers_register_elementor_widgets');

