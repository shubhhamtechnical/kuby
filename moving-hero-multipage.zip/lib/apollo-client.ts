import { ApolloClient, InMemoryCache, HttpLink } from "@apollo/client"

const httpLink = new HttpLink({
  uri: "https://yourwebsite.com/graphql", // Replace with your actual GraphQL endpoint
})

const client = new ApolloClient({
  link: httpLink,
  cache: new InMemoryCache(),
})

export default client

