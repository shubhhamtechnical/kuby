import Link from "next/link"
import { Phone, Mail, MapPin, Menu } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function Navbar() {
  return (
    <header className="w-full bg-brand-blue text-white">
      {/* Top Bar */}
      <div className="hidden md:block border-b border-white/10">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-10 text-sm">
            <div className="flex items-center gap-8">
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4" />
                <Link href="tel:+917248491881">+91 72-4849-1881</Link>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4" />
                <Link href="mailto:info@vermapackers.com">info@vermapackers.com</Link>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="h-4 w-4" />
              <span>Transport nagar, Dehradun (UK)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <div className="container mx-auto px-4">
        <nav className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2">
            <div className="flex flex-col items-start">
              <div className="flex items-center gap-2">
                <svg
                  width="48"
                  height="48"
                  viewBox="0 0 48 48"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="flex-shrink-0"
                >
                  <path d="M24 4L44 24L24 44L4 24L24 4Z" fill="#FDD500" />
                  <text
                    x="24"
                    y="32"
                    textAnchor="middle"
                    fill="#0372FF"
                    fontSize="24"
                    fontWeight="bold"
                    fontFamily="Arial"
                  >
                    V
                  </text>
                </svg>
                <div className="flex flex-col">
                  <span className="text-3xl font-bold leading-none">VERMA</span>
                  <span className="text-sm tracking-wider">PACKERS & MOVERS</span>
                </div>
              </div>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            <Link href="/" className="hover:text-brand-yellow transition-colors">
              Home
            </Link>
            <Link href="/services" className="hover:text-brand-yellow transition-colors">
              Services
            </Link>
            <Link href="/contact" className="hover:text-brand-yellow transition-colors">
              Contact Us
            </Link>
            <Link href="/about" className="hover:text-brand-yellow transition-colors">
              About Us
            </Link>
            <Link href="/policy" className="hover:text-brand-yellow transition-colors">
              Policy
            </Link>
            <Button className="bg-brand-yellow text-brand-blue hover:bg-brand-yellow/90">Get Quote</Button>
          </div>

          {/* Mobile Menu Button */}
          <Button variant="ghost" size="icon" className="md:hidden">
            <Menu className="h-6 w-6" />
            <span className="sr-only">Open menu</span>
          </Button>
        </nav>
      </div>
    </header>
  )
}

