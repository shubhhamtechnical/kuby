import Image from "next/image"

export default function Hero() {
  return (
    <section className="w-full bg-brand-yellow">
      <Image
        src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG-20250221-WA0018.jpg-HTnVQEaSSxbYSQyWyIGVJtNOspFwkp.jpeg"
        alt="Verma Packers & Movers promotional image showing a blue delivery truck on a scenic mountain road"
        width={1080}
        height={1080}
        className="w-full h-auto"
        priority
      />
    </section>
  )
}

