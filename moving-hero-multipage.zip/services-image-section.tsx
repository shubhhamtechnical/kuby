import Image from "next/image"
import { MapPin } from "lucide-react"

export default function ServicesImageSection() {
  return (
    <section className="w-full bg-brand-blue py-12 md:py-16">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          {/* Left Column - Image */}
          <div>
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG-20250221-WA0017.jpg-Lk5GV2Rrh8SgZJRb0fs7anIsLKxo35.jpeg"
              alt="Verma Packers & Movers services overview"
              width={1080}
              height={1080}
              className="w-full h-auto rounded-lg shadow-xl"
            />
          </div>

          {/* Right Column - Location and Contact */}
          <div className="space-y-8">
            <div className="space-y-4">
              <h2 className="text-3xl md:text-4xl font-bold text-brand-yellow">Your perfect shifting partner</h2>
              <p className="text-xl text-white">Hassle-free Shifting across Uttrakhand</p>
            </div>

            <div className="space-y-6">
              <div className="flex items-center gap-3 text-white">
                <MapPin className="h-6 w-6 text-brand-yellow" />
                <p className="text-lg">F-25 Transport Nagar, Dehradun (UK)</p>
              </div>

              <div className="inline-block bg-brand-yellow px-6 py-3 rounded-full">
                <p className="text-xl font-bold text-brand-blue">24/7 SERVICE</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

