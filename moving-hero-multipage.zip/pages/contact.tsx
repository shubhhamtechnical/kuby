import Navbar from "../components/Navbar";

export default function Contact() {
    return (
        <div>
            <Navbar />
            <h1>Contact Us</h1>
            <p>Get in touch with us for inquiries and support.</p>
        </div>
    );
}
