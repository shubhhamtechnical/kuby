import Navbar from "../components/Navbar";

export default function Services() {
    return (
        <div>
            <Navbar />
            <h1>Our Services</h1>
            <p>We offer a variety of services to meet your needs.</p>
        </div>
    );
}
