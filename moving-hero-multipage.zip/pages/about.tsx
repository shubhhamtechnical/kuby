import Navbar from "../components/Navbar";

export default function About() {
    return (
        <div>
            <Navbar />
            <h1>About Us</h1>
            <p>Learn more about our company and team.</p>
        </div>
    );
}
