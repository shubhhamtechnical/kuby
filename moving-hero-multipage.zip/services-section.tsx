import { Globe, Truck, Box, Car, Home, Building2, Factory, Warehouse } from "lucide-react"

export default function ServicesSection() {
  const services = [
    {
      icon: Globe,
      title: "Nationwide Moving",
      description: "Comprehensive moving services across the country",
    },
    {
      icon: Truck,
      title: "Domestic Moving",
      description: "Local and inter-city relocation services",
    },
    {
      icon: Box,
      title: "Household Removal & Storage",
      description: "Complete home moving and storage solutions",
    },
    {
      icon: Car,
      title: "Car Carriers",
      description: "Safe and secure vehicle transportation",
    },
    {
      icon: Home,
      title: "Residential Moving",
      description: "Specialized home relocation services",
    },
    {
      icon: Building2,
      title: "Commercial Moving",
      description: "Business and office relocation solutions",
    },
    {
      icon: Factory,
      title: "Industrial Moving",
      description: "Heavy equipment and industrial relocations",
    },
    {
      icon: Warehouse,
      title: "Warehousing & Virtual Warehouse",
      description: "Secure storage and virtual inventory management",
    },
  ]

  return (
    <section className="w-full bg-white py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-brand-blue mb-4">OUR CORE SERVICES</h2>
          <p className="text-lg text-gray-600">We specialize in performing solutions at</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <div key={index} className="flex flex-col items-center text-center group">
              <div className="w-16 h-16 mb-4 rounded-lg bg-brand-blue/10 flex items-center justify-center group-hover:bg-brand-blue transition-colors duration-300">
                <service.icon className="w-8 h-8 text-brand-blue group-hover:text-white transition-colors duration-300" />
              </div>
              <h3 className="text-lg font-semibold text-gray-800 mb-2">{service.title}</h3>
              <p className="text-sm text-gray-600">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

