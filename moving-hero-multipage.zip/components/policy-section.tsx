import { Shield, Truck, Clock, CreditCard, PackageCheck, BadgeCheck } from "lucide-react"

export default function PolicySection() {
  const policies = [
    {
      icon: Shield,
      title: "Insurance Coverage",
      description: "All shipments are fully insured for maximum protection of your valuable items during transit.",
      points: ["Comprehensive coverage", "Damage protection", "Loss protection", "Quick claim resolution"],
    },
    {
      icon: Truck,
      title: "Transportation Policy",
      description: "We ensure safe and timely delivery of your goods with our professional transportation service.",
      points: ["GPS tracked vehicles", "Experienced drivers", "Regular maintenance", "Route optimization"],
    },
    {
      icon: Clock,
      title: "Timing & Delivery",
      description: "Clear communication and commitment to delivery schedules for your peace of mind.",
      points: ["On-time pickup", "Scheduled delivery", "Real-time updates", "Delay compensation"],
    },
    {
      icon: CreditCard,
      title: "Payment Terms",
      description: "Transparent pricing and flexible payment options to suit your needs.",
      points: ["Multiple payment modes", "No hidden charges", "GST billing", "Advance booking amount"],
    },
    {
      icon: PackageCheck,
      title: "Packing Standards",
      description: "High-quality packing materials and professional techniques for maximum protection.",
      points: ["Quality materials", "Professional packing", "Special item care", "Eco-friendly options"],
    },
    {
      icon: BadgeCheck,
      title: "Service Guarantee",
      description: "We stand behind our service quality with our satisfaction guarantee.",
      points: ["Quality assurance", "Customer satisfaction", "Service warranty", "24/7 support"],
    },
  ]

  return (
    <section id="policy" className="w-full bg-gray-50 py-16 md:py-24 scroll-mt-20">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-block bg-brand-yellow/20 text-brand-blue px-4 py-2 rounded-full mb-4">
            <span className="font-semibold">Our Commitment</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-brand-blue mb-4">Company Policies & Standards</h2>
          <p className="text-lg text-gray-600">
            We maintain strict policies and high standards to ensure the best service quality and customer satisfaction
          </p>
        </div>

        {/* Policies Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {policies.map((policy, index) => (
            <div
              key={index}
              className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow duration-300"
            >
              <div className="flex items-center gap-4 mb-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-lg bg-brand-blue/10 flex items-center justify-center">
                  <policy.icon className="w-6 h-6 text-brand-blue" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900">{policy.title}</h3>
              </div>

              <p className="text-gray-600 mb-6">{policy.description}</p>

              <ul className="space-y-3">
                {policy.points.map((point, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-brand-yellow mt-2 flex-shrink-0" />
                    <span className="text-gray-700">{point}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom Note */}
        <div className="mt-16 text-center">
          <div className="inline-flex items-center justify-center gap-2 bg-brand-blue text-white px-6 py-3 rounded-full">
            <Shield className="w-5 h-5" />
            <span className="font-medium">100% Service Satisfaction Guaranteed</span>
          </div>
        </div>
      </div>
    </section>
  )
}

