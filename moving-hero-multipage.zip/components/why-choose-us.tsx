"use client"

import { motion } from "framer-motion"
import { Shield, Package, CreditCard, Truck, Users } from "lucide-react"

export default function WhyChooseUs() {
  const services = [
    {
      icon: Users,
      title: "Pan India Presence",
      description: "Our extensive network covers all major cities and states across India.",
    },
    {
      icon: Shield,
      title: "Interstate Moving Experts",
      description: "Specialized in long-distance moves with proper documentation and permits.",
    },
    {
      icon: CreditCard,
      title: "Nationwide Coverage",
      description: "Professional moving services available throughout India at competitive rates.",
    },
    {
      icon: Truck,
      title: "Complete Moving Solutions",
      description: "From local to interstate moves, we handle all types of relocations across India.",
    },
    {
      icon: Package,
      title: "Customer Trust",
      description: "Trusted by customers nationwide for reliable and efficient moving services.",
    },
  ]

  return (
    <section
      id="why-choose-us"
      className="w-full bg-brand-blue py-16 md:py-24 scroll-mt-[120px] relative overflow-hidden"
    >
      {/* Decorative Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-0 w-64 h-64 bg-white/5 rounded-full -translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-brand-yellow/10 rounded-full translate-x-1/2 translate-y-1/2" />
        <div className="absolute top-1/2 left-1/2 w-80 h-80 bg-white/5 rounded-full -translate-x-1/2 -translate-y-1/2" />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <div className="inline-block bg-white/10 backdrop-blur-sm text-brand-yellow px-4 py-2 rounded-full mb-4">
            <span className="text-sm md:text-base font-bold">Why Choose Us</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-brand-yellow mb-4">What Makes Us Different?</h2>
          <p className="text-lg text-white/80">Experience excellence in moving services with our dedicated team</p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 md:gap-8 max-w-6xl mx-auto">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group bg-white/10 backdrop-blur-sm rounded-xl p-4 sm:p-6 hover:bg-white/20 transition-all duration-300 border border-white/10"
            >
              <div className="flex flex-col items-center text-center space-y-3 sm:space-y-4">
                <div className="w-12 h-12 sm:w-16 sm:h-16 rounded-full bg-brand-yellow/20 flex items-center justify-center group-hover:bg-brand-yellow/30 transition-colors duration-300">
                  <service.icon className="w-6 h-6 sm:w-8 sm:h-8 text-brand-yellow group-hover:scale-110 transition-transform duration-300" />
                </div>
                <h3 className="text-lg sm:text-xl font-bold text-white group-hover:text-brand-yellow transition-colors duration-300">
                  {service.title}
                </h3>
                <p className="text-sm sm:text-base text-white/80 group-hover:text-white transition-colors duration-300">
                  {service.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mt-16"
        >
          <div className="inline-flex items-center justify-center gap-2 bg-brand-yellow px-6 py-3 rounded-full group hover:bg-white transition-colors duration-300 cursor-pointer">
            <Shield className="w-5 h-5 text-brand-blue" />
            <span className="font-bold text-brand-blue">100% Service Satisfaction Guaranteed</span>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

