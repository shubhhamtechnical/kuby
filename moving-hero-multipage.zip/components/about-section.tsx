"use client"

import { motion } from "framer-motion"
import { Shield, ThumbsUp, MapPin, Truck } from "lucide-react"

export default function AboutSection() {
  const features = [
    {
      icon: MapPin,
      title: "Pan India Network",
      description: "Operating across all major cities and states in India",
    },
    {
      icon: Shield,
      title: "Nationwide Coverage",
      description: "Seamless relocation services throughout India",
    },
    {
      icon: Truck,
      title: "Interstate Services",
      description: "Specialized in long-distance moves across India",
    },
    {
      icon: ThumbsUp,
      title: "Customer Trust",
      description: "Trusted by clients nationwide for reliable service",
    },
  ]

  const serviceAreas = [
    "Delhi NCR",
    "Mumbai",
    "Bangalore",
    "Chennai",
    "Hyderabad",
    "Kolkata",
    "Pune",
    "Ahmedabad",
    "Chandigarh",
    "Lucknow",
    "Jaipur",
    "Dehradun",
  ]

  return (
    <section id="about" className="w-full bg-[#FFF9E5] py-16 md:py-24 scroll-mt-[120px]">
      <div className="container mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <div className="inline-block bg-brand-blue/10 text-brand-blue px-4 py-2 rounded-full mb-4">
            <span className="text-sm md:text-base font-semibold">About Us</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-brand-yellow mb-4">Pan India Moving & Packing Services</h2>
          <p className="text-lg text-gray-700">
            Your trusted partner for nationwide relocation services with a presence across all major Indian cities
          </p>
        </motion.div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-2 gap-12 items-center max-w-7xl mx-auto">
          {/* Left Column - Video */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative rounded-2xl overflow-hidden shadow-xl"
          >
            <video autoPlay muted loop playsInline className="w-full h-auto rounded-lg" poster="/placeholder.svg">
              <source
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/7463950-hd_1920_1080_30fps-U3mNg7SRYt61E6XO7pI6aylsgM3qon.mp4"
                type="video/mp4"
              />
              Your browser does not support the video tag.
            </video>
            <div className="absolute inset-0 bg-brand-blue/10 pointer-events-none" />
          </motion.div>

          {/* Right Column - Content */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <h3 className="text-2xl md:text-3xl font-bold text-brand-yellow">
              India's Leading Moving Services Provider
            </h3>
            <p className="text-gray-700">
              With extensive experience in the packing and moving industry, we have established ourselves as a
              nationwide leader in relocation services. Our network spans across India, enabling us to provide seamless
              moving solutions from any corner of the country to another.
            </p>

            {/* Service Coverage */}
            <div className="bg-white rounded-xl p-6 shadow-lg">
              <h4 className="text-xl font-bold text-brand-blue mb-4">Our Service Network</h4>
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 text-sm">
                {serviceAreas.map((area, index) => (
                  <div key={index} className="bg-gray-50 px-3 py-2 rounded-lg text-center text-gray-700 font-medium">
                    {area}
                  </div>
                ))}
                <div className="bg-brand-yellow/10 px-3 py-2 rounded-lg text-center text-brand-blue font-medium">
                  & More
                </div>
              </div>
            </div>

            {/* Features Grid */}
            <div className="grid gap-6">
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="flex gap-4 items-start"
                >
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-white flex items-center justify-center shadow-md">
                    <feature.icon className="w-6 h-6 text-brand-blue" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-brand-blue mb-1">{feature.title}</h4>
                    <p className="text-gray-700">{feature.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Contact Info */}
            <div className="bg-brand-blue/5 rounded-xl p-6">
              <p className="text-brand-blue font-semibold mb-2">Contact us for pan-India moving services:</p>
              <div className="space-y-2">
                <a href="tel:+917248491881" className="text-gray-700 hover:text-brand-blue block">
                  📞 +91 72-4849-1881
                </a>
                <a href="mailto:Sonuddn81@gmail.com" className="text-gray-700 hover:text-brand-blue block">
                  ✉️ Sonuddn81@gmail.com
                </a>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

