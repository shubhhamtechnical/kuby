"use client"

import { Facebook, Instagram, Phone, Mail } from "lucide-react"
import Link from "next/link"
import MissionVisionModal from "./mission-vision-modal"

export default function Footer() {
  const socialLinks = [
    { icon: Facebook, href: "#", label: "Facebook" },
    {
      icon: Instagram,
      href: "https://www.instagram.com/verma.packersandmovers/?igsh=czN2ZmxwcThneTVu&utm_source=ig_contact_invite",
      label: "Instagram",
    },
  ]

  const navLinks = [
    { href: "/", label: "Home" },
    { href: "/services", label: "Services" },
    { href: "/about", label: "About Us" },
    { href: "tel:+917248491881", label: "+91 72-4849-1881" },
  ]

  const scrollToPrivacyPolicy = () => {
    const privacySection = document.getElementById("privacy-policy")
    if (privacySection) {
      privacySection.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <footer className="w-full bg-[#0a1f44] p-4 md:p-8">
      <div className="container mx-auto">
        {/* White Background Container */}
        <div className="bg-white rounded-xl p-4 md:p-8 shadow-lg">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
            {/* Company Info */}
            <div className="text-center md:text-left">
              <h3 className="text-xl font-medium text-brand-blue mb-4">Verma Packers & Movers</h3>
              <p className="text-gray-600 font-medium mb-2">Your Trusted Moving Partner</p>
              <p className="text-gray-600 font-medium">F-25 Transport Nagar, Dehradun (UK)</p>
            </div>

            {/* Quick Links */}
            <div className="text-center md:text-left">
              <h3 className="text-xl font-medium text-brand-blue mb-4">Quick Links</h3>
              <ul className="space-y-4">
                {navLinks.map((link, index) => (
                  <li key={index}>
                    <Link
                      href={link.href}
                      className="text-gray-600 font-medium hover:text-brand-blue transition-colors block py-1"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Contact Info */}
            <div className="text-center md:text-left">
              <h3 className="text-xl font-medium text-brand-blue mb-4">Contact Us</h3>
              <div className="space-y-4">
                <a
                  href="tel:+917248491881"
                  className="flex items-center justify-center md:justify-start text-gray-600 font-medium hover:text-brand-blue transition-colors py-1"
                >
                  <Phone className="w-5 h-5 mr-2 text-brand-blue" />
                  +91 72-4849-1881
                </a>
                <a
                  href="mailto:Sonuddn81@gmail.com"
                  className="flex items-center justify-center md:justify-start text-gray-600 font-medium hover:text-brand-blue transition-colors py-1"
                >
                  <Mail className="w-5 h-5 mr-2 text-brand-blue" />
                  Sonuddn81@gmail.com
                </a>
              </div>
            </div>

            {/* Legal */}
            <div className="text-center md:text-left">
              <h3 className="text-xl font-medium text-brand-blue mb-4">Legal</h3>
              <div className="space-y-4">
                <div className="py-1">
                  <Link
                    href="#privacy-policy"
                    onClick={(e) => {
                      e.preventDefault()
                      scrollToPrivacyPolicy()
                    }}
                    className="text-gray-600 font-medium hover:text-brand-blue transition-colors"
                  >
                    Privacy Policy
                  </Link>
                </div>
                <div className="py-1">
                  <MissionVisionModal />
                </div>
              </div>
            </div>
          </div>

          {/* Divider */}
          <hr className="my-6 md:my-8 border-gray-200" />

          {/* Bottom Footer */}
          <div className="flex flex-col items-center gap-4 md:flex-row md:justify-between">
            <p className="text-gray-600 font-medium text-center md:text-left text-sm md:text-base">
              © {new Date().getFullYear()} Verma Packers & Movers. All rights reserved.
            </p>
            <div className="flex items-center gap-6">
              {socialLinks.map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-brand-blue hover:text-brand-blue/80 transition-colors p-2"
                >
                  <social.icon className="w-7 h-7" />
                  <span className="sr-only">{social.label}</span>
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}

