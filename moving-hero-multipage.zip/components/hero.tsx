"use client"

import { useState, useEffect } from "react"
import { Menu, X, Phone, MapPin, Truck, Shield } from "lucide-react"
import Logo from "./logo"

export default function Hero() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = "hidden"
    } else {
      document.body.style.overflow = ""
    }
    return () => {
      document.body.style.overflow = ""
    }
  }, [isMobileMenuOpen])

  const navItems = [
    { id: "home", label: "Home" },
    { id: "services-section", label: "Services" },
    { id: "about", label: "About Us" },
    { id: "why-choose-us", label: "Why Choose Us" },
    { id: "testimonials", label: "Testimonials" },
  ]

  const scrollToSection = (sectionId: string) => {
    const section = document.getElementById(sectionId)
    if (section) {
      const headerOffset = isScrolled ? 80 : 96
      const elementPosition = section.getBoundingClientRect().top + window.pageYOffset
      const offsetPosition = elementPosition - headerOffset

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth",
      })
      setIsMobileMenuOpen(false)
    }
  }

  const headerHeight = isScrolled ? "h-16" : "h-20"
  const mobileMenuTop = isScrolled ? "top-16" : "top-20"

  const coverageStats = [
    {
      icon: MapPin,
      number: "500+",
      label: "Cities Covered",
      description: "Across India",
    },
    {
      icon: Truck,
      number: "1000+",
      label: "Monthly Moves",
      description: "Pan India",
    },
    {
      icon: Shield,
      number: "24/7",
      label: "Support",
      description: "Nationwide",
    },
  ]

  return (
    <div className="relative w-full">
      {/* Fixed Header */}
      <div className={`fixed top-0 left-0 right-0 z-50 w-full bg-brand-blue ${headerHeight} safe-top`}>
        {/* Navigation Bar */}
        <div className="container mobile-container">
          <nav className="flex items-center justify-between h-full">
            {/* Logo */}
            <button onClick={() => scrollToSection("home")} className="flex items-center text-white z-50">
              <Logo />
            </button>
            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center gap-6">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className="text-sm text-white hover:text-brand-yellow"
                >
                  {item.label}
                </button>
              ))}
              <a
                href="tel:+917248491881"
                className="bg-brand-yellow text-brand-blue px-4 py-2 rounded-lg text-sm font-medium hover:bg-brand-yellow/90 flex items-center gap-2"
              >
                <Phone className="h-4 w-4" />
                Call Now
              </a>
            </div>
            {/* Mobile Menu Button */}
            <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="lg:hidden text-white z-50">
              {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </nav>
        </div>

        {/* Mobile Menu */}
        <div
          className={`lg:hidden fixed inset-x-0 bg-brand-blue ${mobileMenuTop} transition-all duration-300 ${
            isMobileMenuOpen ? "bottom-0 opacity-100" : "-bottom-full opacity-0 pointer-events-none"
          }`}
        >
          <div className="container mobile-container py-6">
            <div className="flex flex-col space-y-4">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className="text-white hover:text-brand-yellow py-2 text-base"
                >
                  {item.label}
                </button>
              ))}
              <a
                href="tel:+917248491881"
                className="bg-brand-yellow text-brand-blue px-6 py-2.5 rounded-lg text-base font-medium hover:bg-brand-yellow/90 mt-4 flex items-center justify-center gap-2"
              >
                <Phone className="h-4 w-4" />
                Call Now
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Hero Section */}
      <section id="home" className={`w-full scroll-mt-[72px] ${isScrolled ? "pt-[72px]" : "pt-[88px]"}`}>
        <div className="relative bg-white">
          <div className="container mobile-container py-8 lg:py-16">
            <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
              {/* Left Content */}
              <div className="space-y-6 lg:space-y-8 text-center lg:text-left">
                <div className="space-y-4">
                  <div className="inline-block bg-brand-blue/10 text-brand-blue px-4 py-2 rounded-full text-sm font-medium">
                    Pan India Coverage
                  </div>
                  <h1 className="text-2xl sm:text-3xl lg:text-4xl xl:text-5xl font-bold text-brand-yellow leading-tight">
                    India's Trusted Moving & Packing Services
                  </h1>
                  <p className="text-sm sm:text-base lg:text-lg text-gray-600 max-w-2xl mx-auto lg:mx-0">
                    Professional relocation services across all major cities in India. From metropolitan cities to
                    tier-2 towns, we ensure safe and timely delivery nationwide.
                  </p>
                  <div className="flex flex-col sm:flex-row items-center gap-4 justify-center lg:justify-start">
                    <button
                      onClick={() => scrollToSection("quote-form")}
                      className="w-full sm:w-auto px-6 py-3 bg-brand-blue text-white rounded-lg text-sm sm:text-base font-medium hover:bg-brand-blue/90"
                    >
                      Get Free Quote
                    </button>
                    <a
                      href="tel:+917248491881"
                      className="w-full sm:w-auto px-6 py-3 bg-brand-yellow text-brand-blue rounded-lg text-sm sm:text-base font-medium hover:bg-brand-yellow/90 flex items-center justify-center gap-2"
                    >
                      <Phone className="h-4 w-4" />
                      Call Now
                    </a>
                  </div>
                </div>

                {/* Coverage Stats */}
                <div className="grid grid-cols-3 gap-4">
                  {coverageStats.map((stat, index) => (
                    <div key={index} className="bg-white shadow-lg rounded-xl p-4 text-center">
                      <stat.icon className="w-6 h-6 text-brand-blue mx-auto mb-2" />
                      <div className="text-lg sm:text-xl font-bold text-brand-blue">{stat.number}</div>
                      <div className="text-xs font-medium text-gray-600">{stat.label}</div>
                      <div className="text-xs text-brand-yellow mt-1">{stat.description}</div>
                    </div>
                  ))}
                </div>

                {/* Service Areas */}
                <div className="text-sm text-gray-600">
                  <p className="font-medium mb-2">Major Service Areas:</p>
                  <p className="leading-relaxed">
                    Delhi NCR • Mumbai • Bangalore • Chennai • Hyderabad • Kolkata • Pune • Ahmedabad • Chandigarh •
                    Lucknow • Jaipur • Dehradun • And all major cities across India
                  </p>
                </div>
              </div>

              {/* Right Image */}
              <div className="relative">
                <img
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/4342804.jpg-EK5o3ADUagHVKkvROvzvUkRlaq2dBb.jpeg"
                  alt="Professional movers loading furniture into a moving truck"
                  className="w-full h-auto rounded-lg shadow-lg"
                  loading="eager"
                />
                <div className="absolute inset-0 bg-gradient-to-tr from-brand-blue/20 to-transparent rounded-lg" />
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

