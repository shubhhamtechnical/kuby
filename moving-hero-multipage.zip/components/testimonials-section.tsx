"use client"

import { useState, useEffect, useCallback, type TouchEvent } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { ChevronLeft, ChevronRight, Quote } from "lucide-react"
import { Button } from "@/components/ui/button"

const testimonials = [
  {
    id: 1,
    name: "Rajesh Kumar",
    location: "Dehradun",
    role: "Business Owner",
    quote:
      "Verma Packers provided exceptional service during my office relocation. Their team was professional, efficient, and handled everything with great care. Highly recommended!",
    rating: 5,
  },
  {
    id: 2,
    name: "Priya Sharma",
    location: "Haridwar",
    role: "IT Professional",
    quote:
      "Moving from Delhi to Dehradun was stress-free thanks to Verma Packers. They handled all my belongings with utmost care and delivered everything on time.",
    rating: 5,
  },
  {
    id: 3,
    name: "Dr. Amit Patel",
    location: "Rishikesh",
    role: "Clinic Owner",
    quote:
      "Relocating my clinic was a big challenge, but Verma Packers made it seamless. Their expertise in handling medical equipment was impressive. Great service!",
    rating: 5,
  },
  {
    id: 4,
    name: "Meera Gupta",
    location: "Mussoorie",
    role: "School Principal",
    quote:
      "Despite the challenging hill terrain, Verma Packers managed our school equipment relocation perfectly. Their team's professionalism and efficiency were outstanding.",
    rating: 5,
  },
]

export default function TestimonialsSection() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isAutoPlaying, setIsAutoPlaying] = useState(true)
  const [touchStart, setTouchStart] = useState<number | null>(null)

  const nextTestimonial = useCallback(() => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length)
  }, [])

  const previousTestimonial = useCallback(() => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length)
  }, [])

  // Auto-play functionality
  useEffect(() => {
    let intervalId: NodeJS.Timeout

    if (isAutoPlaying) {
      intervalId = setInterval(() => {
        nextTestimonial()
      }, 10000) // Changed from 5000 to 10000
    }

    return () => {
      if (intervalId) {
        clearInterval(intervalId)
      }
    }
  }, [isAutoPlaying, nextTestimonial])

  // Touch handlers for swipe functionality
  const handleTouchStart = (e: TouchEvent) => {
    setIsAutoPlaying(false)
    setTouchStart(e.touches[0].clientX)
  }

  const handleTouchMove = (e: TouchEvent) => {
    if (!touchStart) return

    const currentTouch = e.touches[0].clientX
    const diff = touchStart - currentTouch

    // Swipe threshold of 50px
    if (Math.abs(diff) > 50) {
      if (diff > 0) {
        nextTestimonial()
      } else {
        previousTestimonial()
      }
      setTouchStart(null)
    }
  }

  const handleTouchEnd = () => {
    setTouchStart(null)
    setIsAutoPlaying(true)
  }

  // Interaction handlers
  const handleInteractionStart = () => {
    setIsAutoPlaying(false)
  }

  const handleInteractionEnd = () => {
    setIsAutoPlaying(true)
  }

  return (
    <section
      id="testimonials"
      className="w-full bg-gradient-to-b from-gray-50 to-white py-8 sm:py-12 md:py-20 scroll-mt-[72px] md:scroll-mt-[120px]"
    >
      <div className="container mx-auto px-4 sm:px-6">
        <div className="text-center max-w-3xl mx-auto mb-6 sm:mb-8 md:mb-12">
          <h2 className="text-xl sm:text-2xl md:text-3xl font-bold text-brand-yellow mb-2 sm:mb-3">Customer Reviews</h2>
          <p className="text-xs sm:text-sm md:text-base text-gray-600 font-medium px-4">
            What our valued customers say about our services
          </p>
        </div>

        <div className="relative max-w-4xl mx-auto">
          {/* Testimonials Slider */}
          <div
            className="overflow-hidden touch-pan-y"
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleTouchEnd}
            onMouseEnter={handleInteractionStart}
            onMouseLeave={handleInteractionEnd}
          >
            <AnimatePresence mode="wait">
              <motion.div
                key={currentIndex}
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                transition={{ duration: 0.3 }}
                className="bg-white rounded-lg sm:rounded-xl md:rounded-2xl p-4 sm:p-6 md:p-8 shadow-lg relative mx-auto"
              >
                {/* Progress Bar */}
                <div className="absolute top-0 left-0 w-full h-0.5 bg-gray-100 overflow-hidden">
                  <motion.div
                    className="h-full bg-brand-blue"
                    initial={{ width: "0%" }}
                    animate={{ width: "100%" }}
                    transition={{
                      duration: 10, // Changed from 5 to 10
                      ease: "linear",
                      repeat: isAutoPlaying ? Number.POSITIVE_INFINITY : 0,
                    }}
                    key={`progress-${currentIndex}`}
                  />
                </div>

                {/* Quote Icon */}
                <Quote className="w-6 h-6 sm:w-8 sm:h-8 md:w-10 md:h-10 text-brand-yellow mb-3 sm:mb-4 md:mb-6" />

                {/* Content */}
                <div className="space-y-3 sm:space-y-4 md:space-y-6">
                  <blockquote className="relative">
                    <p className="text-sm sm:text-base md:text-lg text-gray-700 font-bold leading-relaxed">
                      "{testimonials[currentIndex].quote}"
                    </p>
                  </blockquote>

                  <div className="flex items-center justify-between border-t pt-3 sm:pt-4 md:pt-6">
                    <div>
                      <h3 className="text-base sm:text-lg md:text-xl font-bold text-gray-900">
                        {testimonials[currentIndex].name}
                      </h3>
                      <p className="text-xs sm:text-sm md:text-base font-bold text-brand-blue">
                        {testimonials[currentIndex].role}
                      </p>
                      <p className="text-xs md:text-sm text-gray-500 font-medium">
                        {testimonials[currentIndex].location}
                      </p>
                    </div>
                    <div className="flex gap-0.5 sm:gap-1">
                      {[...Array(testimonials[currentIndex].rating)].map((_, i) => (
                        <svg
                          key={i}
                          className="w-3 h-3 sm:w-4 sm:h-4 md:w-5 md:h-5 text-yellow-400"
                          fill="currentColor"
                          viewBox="0 0 20 20"
                        >
                          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Navigation */}
          <div className="flex justify-center items-center gap-2 sm:gap-3 md:gap-4 mt-4 sm:mt-6 md:mt-8">
            <Button
              variant="outline"
              size="icon"
              onClick={previousTestimonial}
              className="h-7 w-7 sm:h-8 sm:w-8 md:h-10 md:w-10 rounded-full hover:bg-brand-blue hover:text-white transition-colors"
            >
              <ChevronLeft className="h-3 w-3 sm:h-4 sm:w-4" />
            </Button>

            {/* Progress Dots */}
            <div className="flex gap-1 sm:gap-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentIndex(index)}
                  className={`w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full transition-all duration-300 ${
                    index === currentIndex ? "w-4 sm:w-6 md:w-8 bg-brand-blue" : "bg-gray-300 hover:bg-gray-400"
                  }`}
                  aria-label={`Go to testimonial ${index + 1}`}
                />
              ))}
            </div>

            <Button
              variant="outline"
              size="icon"
              onClick={nextTestimonial}
              className="h-7 w-7 sm:h-8 sm:w-8 md:h-10 md:w-10 rounded-full hover:bg-brand-blue hover:text-white transition-colors"
            >
              <ChevronRight className="h-3 w-3 sm:h-4 sm:w-4" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}

