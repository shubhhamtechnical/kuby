"use client"

import { useEffect, useRef } from "react"
import { motion, useScroll, useTransform } from "framer-motion"

export default function EnhancedBackground() {
  const { scrollY } = useScroll()
  const ref = useRef<HTMLDivElement>(null)

  // Parallax effects
  const y1 = useTransform(scrollY, [0, 1000], [0, 300])
  const y2 = useTransform(scrollY, [0, 1000], [0, -300])
  const opacity = useTransform(scrollY, [0, 300], [1, 0.5])

  // Create animated particles
  useEffect(() => {
    if (!ref.current) return

    const canvas = document.createElement("canvas")
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    canvas.style.position = "absolute"
    canvas.style.top = "0"
    canvas.style.left = "0"
    canvas.style.width = "100%"
    canvas.style.height = "100%"
    canvas.style.opacity = "0.1"
    ref.current.appendChild(canvas)

    const resizeCanvas = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }
    resizeCanvas()
    window.addEventListener("resize", resizeCanvas)

    // Particle system
    const particles: { x: number; y: number; speed: number; size: number }[] = []
    for (let i = 0; i < 50; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        speed: Math.random() * 0.5 + 0.2,
        size: Math.random() * 3 + 1,
      })
    }

    const animate = () => {
      if (!ctx) return
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      particles.forEach((particle) => {
        particle.y += particle.speed
        if (particle.y > canvas.height) {
          particle.y = 0
        }

        // Draw particle
        ctx.beginPath()
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2)
        ctx.fillStyle = Math.random() > 0.5 ? "#0372FF" : "#FDD500"
        ctx.fill()
      })

      requestAnimationFrame(animate)
    }
    animate()

    return () => {
      window.removeEventListener("resize", resizeCanvas)
      if (ref.current) {
        ref.current.removeChild(canvas)
      }
    }
  }, [])

  return (
    <div ref={ref} className="fixed inset-0 -z-10 overflow-hidden">
      {/* Gradient Base */}
      <div className="absolute inset-0 bg-gradient-to-b from-brand-blue via-brand-blue/50 to-brand-yellow/30" />

      {/* Animated Gradient Orbs */}
      <motion.div style={{ opacity }} className="absolute inset-0">
        <motion.div style={{ y: y1 }} className="absolute inset-0">
          <div className="absolute top-1/4 left-1/4 w-64 h-64 rounded-full bg-brand-yellow/10 blur-3xl animate-pulse" />
          <div className="absolute top-3/4 right-1/4 w-96 h-96 rounded-full bg-brand-blue/10 blur-3xl animate-pulse" />
        </motion.div>

        <motion.div style={{ y: y2 }} className="absolute inset-0">
          <div className="absolute top-1/2 left-1/2 w-80 h-80 rounded-full bg-brand-yellow/20 blur-3xl animate-pulse" />
          <div className="absolute bottom-1/4 right-1/3 w-72 h-72 rounded-full bg-brand-blue/20 blur-3xl animate-pulse" />
        </motion.div>
      </motion.div>

      {/* Pattern Overlay */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0 pattern-grid" />
      </div>

      {/* Animated Lines */}
      <div className="absolute inset-0">
        <svg width="100%" height="100%" className="opacity-10">
          <defs>
            <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" style={{ stopColor: "#0372FF", stopOpacity: 0.2 }} />
              <stop offset="100%" style={{ stopColor: "#FDD500", stopOpacity: 0.2 }} />
            </linearGradient>
          </defs>
          <pattern id="pattern1" width="100" height="100" patternUnits="userSpaceOnUse">
            <path d="M0 50 Q 25 0, 50 50 T 100 50" stroke="url(#grad1)" fill="none" strokeWidth="2">
              <animateTransform
                attributeName="transform"
                type="translate"
                from="0 0"
                to="-100 0"
                dur="10s"
                repeatCount="indefinite"
              />
            </path>
          </pattern>
          <rect width="100%" height="100%" fill="url(#pattern1)" />
        </svg>
      </div>
    </div>
  )
}

