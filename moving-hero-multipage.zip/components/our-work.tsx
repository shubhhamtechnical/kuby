"use client"

import { motion } from "framer-motion"
import { Truck, Package, Users, CheckCircle } from "lucide-react"
import { CountdownStats } from "./countdown-stats"

export default function OurWork() {
  const stats = [
    { icon: Truck, label: "Successful Moves" },
    { icon: CheckCircle, label: "Years Experience" },
    { icon: Users, label: "Expert Team" },
    { icon: Package, label: "Happy Customers" },
  ]

  return (
    <section className="w-full bg-[#FFF9E5] py-16 md:py-24">
      <div className="container mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <div className="inline-block bg-brand-blue/10 text-brand-blue px-4 py-2 rounded-full mb-4">
            <span className="text-sm md:text-base font-semibold">Our Work</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-brand-yellow mb-4">Our Achievements</h2>
          <p className="text-lg text-gray-700">Years of excellence in providing quality moving and packing services</p>
        </motion.div>

        {/* Stats Grid */}
        <div className="max-w-4xl mx-auto">
          <CountdownStats />
        </div>

        {/* Additional Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mt-16"
        >
          <p className="text-lg text-gray-700 max-w-2xl mx-auto">
            Trust in our experience and expertise to handle your valuable belongings with the utmost care and
            professionalism.
          </p>
        </motion.div>
      </div>
    </section>
  )
}

