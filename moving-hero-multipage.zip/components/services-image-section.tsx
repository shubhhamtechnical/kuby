import { Check } from "lucide-react"

export default function ServicesImageSection() {
  const services = ["Home Shifting", "Bick & Car Shifting", "Residential & Commercial", "Insurance & Warehousing"]

  return (
    <section className="w-full bg-brand-blue py-12 md:py-16">
      <div className="container mx-auto px-4">
        <div className="space-y-8 max-w-2xl">
          {/* Header with NEW ARRIVAL badge */}
          <div className="space-y-6">
            <div className="inline-block bg-brand-yellow px-4 py-2 rounded-full">
              <span className="text-brand-blue font-semibold">NEW ARRIVAL</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-white">Welcome to our page!</h2>
            <p className="text-xl text-white/90">We provide relocation & transportation service across the nation.</p>
          </div>

          {/* Services List */}
          <div className="space-y-4">
            {services.map((service, index) => (
              <div key={index} className="flex items-center gap-3">
                <div className="flex-shrink-0 h-6 w-6 rounded-full bg-brand-yellow flex items-center justify-center">
                  <Check className="h-4 w-4 text-brand-blue" />
                </div>
                <span className="text-lg text-white font-medium">{service}</span>
              </div>
            ))}
          </div>

          {/* Bottom Section */}
          <div className="pt-4">
            <h3 className="text-xl font-semibold text-brand-yellow">Hassle-free Shifting</h3>
          </div>
        </div>
      </div>
    </section>
  )
}

