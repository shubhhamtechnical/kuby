"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Phone, Mail, Globe } from "lucide-react"

export default function PrivacyPolicyTooltip() {
  const [isHovered, setIsHovered] = useState(false)
  const [isTouched, setIsTouched] = useState(false)

  const handleClick = () => {
    setIsTouched(!isTouched)
  }

  return (
    <div className="relative inline-block">
      <button
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        className="text-gray-600 font-medium hover:text-brand-blue transition-colors py-2 px-4 -mx-4 rounded-lg"
        onClick={() => window.open("/privacy-policy", "_blank", "noopener,noreferrer")}
      >
        Privacy Policy
      </button>

      <AnimatePresence>
        {(isHovered || isTouched) && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="fixed md:absolute left-4 right-4 md:left-0 bottom-4 md:bottom-full md:mb-2 md:w-[400px] bg-white rounded-lg shadow-xl p-6 text-left z-50 border border-gray-100"
          >
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-brand-blue text-lg mb-2">Information We Collect</h3>
                <p className="text-sm text-gray-600">
                  When you interact with Verma Packers & Movers, we may collect personal information such as your name,
                  phone number, email address, postal address, and moving details. We may also gather technical
                  information like IP addresses and website usage data.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-brand-blue text-lg mb-2">How We Use Your Information</h3>
                <p className="text-sm text-gray-600">
                  We use this information to provide and manage our moving services, communicate with you about bookings
                  and promotions, improve our website, and comply with legal obligations.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-brand-blue text-lg mb-2">Data Security</h3>
                <p className="text-sm text-gray-600">
                  We take appropriate measures to protect your personal information from unauthorized access, loss, or
                  misuse. Your data is handled securely.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-brand-blue text-lg mb-2">Your Rights</h3>
                <p className="text-sm text-gray-600">
                  You have the right to access, update, or delete your personal information and opt-out of marketing
                  communications at any time.
                </p>
              </div>

              <div className="pt-4 border-t border-gray-200">
                <h3 className="font-semibold text-brand-blue text-lg mb-2">Contact Us</h3>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Phone className="w-4 h-4 text-brand-blue" />
                    <a href="tel:+917248491881" className="hover:text-brand-blue">
                      +91 72-4849-1881
                    </a>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Mail className="w-4 h-4 text-brand-blue" />
                    <a
                      href="mailto:Sonuddn81@gmail.com"
                      className="text-gray-600 dark:text-gray-400 hover:text-brand-blue"
                    >
                      Sonuddn81@gmail.com
                    </a>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Globe className="w-4 h-4 text-brand-blue" />
                    <span>www.vermapackers.com</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Close button for mobile */}
            <button
              onClick={() => setIsTouched(false)}
              className="absolute top-2 right-2 md:hidden text-gray-400 hover:text-gray-600 p-2"
            >
              ✕
            </button>

            {/* Arrow (desktop only) */}
            <div className="hidden md:block absolute -bottom-2 left-4 w-4 h-4 bg-white transform rotate-45 border-r border-b border-gray-100" />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

