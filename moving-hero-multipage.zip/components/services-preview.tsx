"use client"

import { motion } from "framer-motion"
import { Globe, Truck, Box, Car, Home, Building2 } from "lucide-react"
import Link from "next/link"

export default function ServicesPreview() {
  const services = [
    {
      icon: Globe,
      title: "Nationwide Moving",
      description: "Comprehensive moving services across the country",
    },
    {
      icon: Truck,
      title: "Domestic Moving",
      description: "Local and inter-city relocation services",
    },
    {
      icon: Box,
      title: "Household Removal",
      description: "Complete home moving solutions",
    },
    {
      icon: Car,
      title: "Car Carriers",
      description: "Safe vehicle transportation",
    },
    {
      icon: Home,
      title: "Residential Moving",
      description: "Specialized home relocation",
    },
    {
      icon: Building2,
      title: "Commercial Moving",
      description: "Business relocation solutions",
    },
  ]

  return (
    <section className="w-full bg-white py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-brand-blue mb-4">Our Services</h2>
          <p className="text-lg text-gray-600">Professional moving solutions for all your needs</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-8 max-w-6xl mx-auto mb-12">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="flex flex-col items-center text-center group"
            >
              <div className="w-16 h-16 mb-4 rounded-lg bg-brand-blue/10 flex items-center justify-center group-hover:bg-brand-blue transition-colors duration-300">
                <service.icon className="w-8 h-8 text-brand-blue group-hover:text-white transition-colors duration-300" />
              </div>
              <h3 className="text-lg font-semibold text-gray-800 mb-2">{service.title}</h3>
              <p className="text-sm text-gray-600">{service.description}</p>
            </motion.div>
          ))}
        </div>

        <div className="text-center">
          <Link
            href="/services"
            className="inline-flex items-center justify-center px-8 py-3 bg-brand-blue text-white rounded-lg hover:bg-brand-blue/90 transition-colors"
          >
            View All Services
          </Link>
        </div>
      </div>
    </section>
  )
}

