"use client"

import { motion } from "framer-motion"
import AnimatedServiceBox from "./animated-service-box"

const services = [
  {
    number: "01",
    title: "Expert Staff",
    description: "Our professional team ensures safe and efficient moving services",
    icon: "users" as const,
  },
  {
    number: "02",
    title: "Logistic Services",
    description: "Complete logistics solutions for all your moving needs",
    icon: "truck" as const,
  },
  {
    number: "03",
    title: "Package Protection",
    description: "Your belongings are protected with utmost care",
    icon: "package" as const,
  },
]

export default function ServicesGrid() {
  return (
    <section className="w-full bg-gray-50 py-16 md:py-24">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <span className="text-brand-blue font-semibold text-sm uppercase tracking-wider">Our Services</span>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mt-2">What We Provide</h2>
          <p className="text-gray-600 mt-4">Professional moving services tailored to your needs</p>
        </motion.div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {services.map((service, index) => (
            <AnimatedServiceBox
              key={index}
              number={service.number}
              title={service.title}
              description={service.description}
              icon={service.icon}
            />
          ))}
        </div>
      </div>
    </section>
  )
}

