"use client"

import { motion } from "framer-motion"

export default function MissionVision() {
  return (
    <section className="bg-gray-900 py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-8">Our Vision</h2>
            <p className="text-lg md:text-xl text-gray-300 leading-relaxed">
              Our vision is to become{" "}
              <span className="text-brand-yellow font-semibold">
                India's most trusted and preferred relocation service provider
              </span>{" "}
              by delivering exceptional moving solutions. We aim to set industry benchmarks with{" "}
              <span className="text-brand-yellow font-semibold">
                innovative packing techniques, advanced logistics, and outstanding customer support
              </span>
              . We strive to build long-term relationships with our customers through professionalism, integrity, and
              continuous improvement in our services.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-8">Our Mission</h2>
            <p className="text-lg md:text-xl text-gray-300 leading-relaxed">
              At Verma Packers and Movers, our mission is to provide{" "}
              <span className="text-brand-yellow font-semibold">
                seamless, reliable, and efficient relocation services
              </span>{" "}
              tailored to meet our customers' unique needs. We are committed to ensuring a{" "}
              <span className="text-brand-yellow font-semibold">stress-free moving experience</span> with safe handling,
              secure transportation, and timely delivery of goods. Our focus is on maintaining{" "}
              <span className="text-brand-yellow font-semibold">
                high-quality service standards, transparency, and customer satisfaction
              </span>{" "}
              at every step of the process.
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

