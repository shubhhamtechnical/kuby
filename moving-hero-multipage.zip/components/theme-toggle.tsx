"use client"

import { Moon, Sun } from "lucide-react"
import { useTheme } from "@/contexts/theme-context"
import { motion } from "framer-motion"

export default function ThemeToggle() {
  const { theme, toggleTheme } = useTheme()

  return (
    <button
      onClick={toggleTheme}
      className="relative h-8 w-14 rounded-full bg-white/20 p-1 shadow-inner hover:bg-white/30 transition-colors"
      aria-label="Toggle theme"
    >
      <motion.div
        className="absolute h-6 w-6 rounded-full"
        animate={{
          backgroundColor: theme === "blue" ? "#FDD500" : "#0372FF",
          x: theme === "blue" ? 0 : 24,
        }}
        transition={{ type: "spring", stiffness: 300, damping: 24 }}
      >
        {theme === "blue" ? (
          <Sun className="h-6 w-6 text-brand-blue p-1" />
        ) : (
          <Moon className="h-6 w-6 text-white p-1" />
        )}
      </motion.div>
    </button>
  )
}

