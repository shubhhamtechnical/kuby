"use client"

import { useState, useEffect, useRef } from "react"

export default function StatsSection() {
  const [counts, setCounts] = useState({
    years: 0,
    shiftings: 0,
    locations: 0,
  })

  const targetRef = useRef(null)
  const hasAnimated = useRef(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const [entry] = entries
        if (entry.isIntersecting && !hasAnimated.current) {
          startCounting()
          hasAnimated.current = true
        }
      },
      { threshold: 0.1 },
    )

    if (targetRef.current) {
      observer.observe(targetRef.current)
    }

    return () => {
      if (targetRef.current) {
        observer.unobserve(targetRef.current)
      }
    }
  }, [])

  const startCounting = () => {
    let startTime: number | null = null
    const duration = 2000 // 2 seconds

    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime
      const progress = Math.min((currentTime - startTime) / duration, 1)

      setCounts({
        years: Math.min(Math.floor(progress * 4), 4),
        shiftings: Math.min(Math.floor(progress * 150), 150),
        locations: Math.min(Math.floor(progress * 15), 15),
      })

      if (progress < 1) {
        requestAnimationFrame(animate)
      }
    }

    requestAnimationFrame(animate)
  }

  return (
    <section ref={targetRef} className="w-full bg-white py-12 border-t border-gray-100">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {/* Experience */}
          <div className="text-center">
            <div className="text-3xl md:text-4xl font-bold text-brand-blue mb-1">{counts.years}+ Years</div>
            <div className="text-sm text-gray-600">Experience</div>
            <div className="text-xs text-gray-500 mt-1">+ 2 days, 5 hours</div>
          </div>

          {/* Shiftings */}
          <div className="text-center">
            <div className="text-3xl md:text-4xl font-bold text-brand-blue mb-1">{counts.shiftings}+ Done</div>
            <div className="text-sm text-gray-600">Shiftings</div>
            <div className="text-xs text-gray-500 mt-1">Out of 150+ total</div>
          </div>

          {/* Service Locations */}
          <div className="text-center">
            <div className="text-3xl md:text-4xl font-bold text-brand-blue mb-1">{counts.locations}+</div>
            <div className="text-sm text-gray-600">Service Locations</div>
          </div>

          {/* Customer Support */}
          <div className="text-center">
            <div className="text-3xl md:text-4xl font-bold text-brand-blue mb-1">24/7</div>
            <div className="text-sm text-gray-600">Customer Support</div>
          </div>
        </div>
      </div>
    </section>
  )
}

