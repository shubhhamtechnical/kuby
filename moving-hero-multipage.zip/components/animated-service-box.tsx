"use client"

import { motion } from "framer-motion"
import { Truck, Package, Users } from "lucide-react"

interface ServiceBoxProps {
  number: string
  title: string
  description: string
  icon: "truck" | "package" | "users"
}

const icons = {
  truck: Truck,
  package: Package,
  users: Users,
}

export default function AnimatedServiceBox({ number, title, description, icon }: ServiceBoxProps) {
  const Icon = icons[icon]

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      whileHover={{ y: -10 }}
      transition={{ duration: 0.3 }}
      className="relative bg-white rounded-lg p-6 shadow-lg group hover:shadow-xl transition-all duration-300"
    >
      {/* Animated background overlay */}
      <motion.div
        className="absolute inset-0 bg-brand-blue rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"
        initial={false}
      />

      {/* Content */}
      <div className="relative z-10">
        {/* Number */}
        <span className="text-4xl font-bold text-brand-blue/10 group-hover:text-white/10 transition-colors duration-300">
          {number}
        </span>

        {/* Icon */}
        <div className="mb-4">
          <Icon className="w-12 h-12 text-brand-blue group-hover:text-white transition-colors duration-300" />
        </div>

        {/* Title */}
        <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-white transition-colors duration-300">
          {title}
        </h3>

        {/* Description */}
        <p className="text-gray-600 group-hover:text-white/90 transition-colors duration-300">{description}</p>
      </div>
    </motion.div>
  )
}

