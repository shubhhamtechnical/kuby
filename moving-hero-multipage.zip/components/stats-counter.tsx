"use client"

import { useState, useEffect, useRef } from "react"
import { motion } from "framer-motion"

interface CounterProps {
  end: number
  label: string
  duration?: number
}

const Counter = ({ end, label, duration = 2000 }: CounterProps) => {
  const [count, setCount] = useState(0)
  const countRef = useRef<number>(0)
  const [isVisible, setIsVisible] = useState(false)
  const elementRef = useRef(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.5 },
    )

    if (elementRef.current) {
      observer.observe(elementRef.current)
    }

    return () => {
      if (elementRef.current) {
        observer.unobserve(elementRef.current)
      }
    }
  }, [])

  useEffect(() => {
    if (!isVisible) return

    const startTime = Date.now()
    const counter = setInterval(() => {
      const now = Date.now()
      const progress = Math.min((now - startTime) / duration, 1)

      countRef.current = Math.floor(progress * end)
      setCount(countRef.current)

      if (progress === 1) {
        clearInterval(counter)
      }
    }, 16)

    return () => clearInterval(counter)
  }, [end, duration, isVisible])

  return (
    <motion.div
      ref={elementRef}
      initial={{ opacity: 0, y: 20 }}
      animate={isVisible ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.5 }}
      className="bg-brand-blue p-6 rounded-lg text-center"
    >
      <div className="text-4xl md:text-5xl font-bold text-white mb-2">{count}</div>
      <div className="text-sm text-white/80 uppercase tracking-wider">{label}</div>
    </motion.div>
  )
}

export default function StatsCounter() {
  const stats = [
    { value: 4, label: "Years Experience" },
    { value: 155, label: "Successful Shiftings" },
    { value: 22, label: "Expert Team Members" },
    { value: 152, label: "Happy Customers" },
  ]

  return (
    <section className="w-full bg-[#FFF9E5] py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-brand-yellow mb-4">About Us & Our Work</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            We take pride in our work and the trust our clients place in us. Here are some numbers that tell our story.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-5xl mx-auto">
          {stats.map((stat, index) => (
            <Counter key={index} end={stat.value} label={stat.label} />
          ))}
        </div>
      </div>
    </section>
  )
}

