"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef, type ReactNode } from "react"

interface AnimatedContainerProps {
  children: ReactNode
  className?: string
  animation?: "fade" | "slide" | "scale" | "rotate"
  delay?: number
}

export default function AnimatedContainer({
  children,
  className = "",
  animation = "fade",
  delay = 0,
}: AnimatedContainerProps) {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: false, margin: "-100px" })

  const animations = {
    fade: {
      initial: { opacity: 0, y: 20 },
      animate: { opacity: 1, y: 0 },
    },
    slide: {
      initial: { x: -100, opacity: 0 },
      animate: { x: 0, opacity: 1 },
    },
    scale: {
      initial: { scale: 0.8, opacity: 0 },
      animate: { scale: 1, opacity: 1 },
    },
    rotate: {
      initial: { rotate: -10, opacity: 0 },
      animate: { rotate: 0, opacity: 1 },
    },
  }

  return (
    <motion.div
      ref={ref}
      initial={animations[animation].initial}
      animate={isInView ? animations[animation].animate : animations[animation].initial}
      transition={{ duration: 0.8, delay, ease: "easeOut" }}
      className={`${className} hover-glow`}
    >
      {children}
    </motion.div>
  )
}

