"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { QrCode, Copy, Check } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function UPIPayment() {
  const [copied, setCopied] = useState(false)
  const upiId = "vermapackers@upi"

  const handleCopy = () => {
    navigator.clipboard.writeText(upiId)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="bg-white rounded-lg shadow-lg p-6 max-w-sm mx-auto"
    >
      <div className="text-center mb-6">
        <QrCode className="w-12 h-12 text-brand-blue mx-auto mb-2" />
        <h3 className="text-xl font-bold text-gray-900">Pay with UPI</h3>
        <p className="text-gray-600 text-sm mt-1">Quick and secure payment</p>
      </div>

      <div className="flex items-center gap-2 bg-gray-50 rounded-lg p-3 mb-4">
        <span className="text-gray-700 flex-1 font-medium">{upiId}</span>
        <Button variant="ghost" size="sm" className="text-brand-blue hover:text-brand-blue/80" onClick={handleCopy}>
          {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
        </Button>
      </div>

      <div className="space-y-3">
        <Button
          className="w-full bg-brand-blue hover:bg-brand-blue/90"
          onClick={() => window.open(`upi://pay?pa=${upiId}`)}
        >
          Pay Now
        </Button>
        <p className="text-xs text-gray-500 text-center">
          Supports all UPI apps including Google Pay, PhonePe, and Paytm
        </p>
      </div>
    </motion.div>
  )
}

