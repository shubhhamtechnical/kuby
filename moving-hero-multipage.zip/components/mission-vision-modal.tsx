"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { X } from "lucide-react"

export default function MissionVisionModal() {
  const [isOpen, setIsOpen] = useState(false)

  const toggleModal = () => setIsOpen(!isOpen)

  return (
    <>
      <button
        onClick={toggleModal}
        className="text-sm md:text-base text-white hover:text-brand-yellow transition-colors"
      >
        Mission & Vision
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={toggleModal}
            className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ y: -50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -50, opacity: 0 }}
              className="bg-gray-900 p-6 rounded-lg max-w-2xl w-full relative"
              onClick={(e) => e.stopPropagation()}
            >
              <button onClick={toggleModal} className="absolute top-4 right-4 text-white hover:text-brand-yellow">
                <X size={24} />
              </button>

              <div className="space-y-8">
                <div>
                  <h2 className="text-3xl font-bold text-brand-yellow mb-4">Our Mission</h2>
                  <p className="text-white text-lg">
                    At Verma Packers and Movers, our mission is to provide seamless, reliable, and efficient relocation
                    services tailored to meet our customers' unique needs. We are committed to ensuring a stress-free
                    moving experience with safe handling, secure transportation, and timely delivery of goods. Our focus
                    is on maintaining high-quality service standards, transparency, and customer satisfaction at every
                    step of the process.
                  </p>
                </div>

                <div>
                  <h2 className="text-3xl font-bold text-brand-yellow mb-4">Our Vision</h2>
                  <p className="text-white text-lg">
                    Our vision is to become India's most trusted and preferred relocation service provider by delivering
                    exceptional moving solutions. We aim to set industry benchmarks with innovative packing techniques,
                    advanced logistics, and outstanding customer support. We strive to build long-term relationships
                    with our customers through professionalism, integrity, and continuous improvement in our services.
                  </p>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}

