export default function PrivacyPolicySection() {
  return (
    <section id="privacy-policy" className="w-full bg-gray-50 py-16 md:py-24 scroll-mt-[120px]">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-lg p-6 md:p-8">
          <h2 className="text-3xl font-bold text-brand-blue mb-8">Privacy Policy</h2>

          <div className="space-y-8">
            <section>
              <h3 className="text-xl font-semibold text-gray-800 mb-4">Information We Collect</h3>
              <p className="text-gray-600">
                When you interact with Verma Packers & Movers, we may collect personal information such as your name,
                phone number, email address, postal address, and moving details. We may also gather technical
                information like IP addresses and website usage data.
              </p>
            </section>

            <section>
              <h3 className="text-xl font-semibold text-gray-800 mb-4">How We Use Your Information</h3>
              <p className="text-gray-600">We use this information to:</p>
              <ul className="list-disc pl-6 mt-2 space-y-2 text-gray-600">
                <li>Provide and manage our moving services</li>
                <li>Communicate with you about bookings and promotions</li>
                <li>Improve our website and services</li>
                <li>Comply with legal obligations</li>
              </ul>
            </section>

            <section>
              <h3 className="text-xl font-semibold text-gray-800 mb-4">Data Security</h3>
              <p className="text-gray-600">
                We implement appropriate security measures to protect your personal information from unauthorized
                access, loss, or misuse. However, no method of transmission over the internet is 100% secure, and we
                cannot guarantee absolute security.
              </p>
            </section>

            <section>
              <h3 className="text-xl font-semibold text-gray-800 mb-4">Your Rights</h3>
              <p className="text-gray-600">You have the right to:</p>
              <ul className="list-disc pl-6 mt-2 space-y-2 text-gray-600">
                <li>Access your personal information</li>
                <li>Correct inaccurate information</li>
                <li>Request deletion of your information</li>
                <li>Opt-out of marketing communications</li>
              </ul>
            </section>

            <section>
              <h3 className="text-xl font-semibold text-gray-800 mb-4">Contact Us</h3>
              <p className="text-gray-600 mb-4">If you have questions about this Privacy Policy, please contact us:</p>
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-gray-600">Email: Sonuddn81@gmail.com</p>
                <p className="text-gray-600">Phone: +91 72-4849-1881</p>
                <p className="text-gray-600">Address: F-25 Transport Nagar, Dehradun (UK)</p>
              </div>
            </section>

            <section>
              <h3 className="text-xl font-semibold text-gray-800 mb-4">Updates to This Policy</h3>
              <p className="text-gray-600">
                We may update this Privacy Policy from time to time. The latest version will always be available on our
                website. By continuing to use our services after any changes, you accept the updated Privacy Policy.
              </p>
            </section>
          </div>
        </div>
      </div>
    </section>
  )
}

