"use client"

import { useState, useEffect } from "react"
import { Menu, X, Phone } from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import Logo from "./logo"

export default function Navbar() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)
  const pathname = usePathname()

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const navItems = [
    { href: "/", label: "Home" },
    { href: "/services", label: "Services" },
    { href: "/about", label: "About Us" },
    { href: "/contact", label: "Contact" },
  ]

  const isActive = (path: string) => pathname === path

  const headerHeight = isScrolled ? "h-16" : "h-20"

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 w-full bg-brand-blue ${headerHeight} transition-all duration-300`}
    >
      <div className="container mx-auto px-4">
        <nav className="flex items-center justify-between h-full">
          {/* Logo */}
          <Link href="/" className="flex items-center text-white z-50">
            <Logo />
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            {navItems.map((item, index) => (
              <Link
                key={index}
                href={item.href}
                className={`transition-colors ${
                  isActive(item.href) ? "text-brand-yellow" : "text-white hover:text-brand-yellow"
                }`}
              >
                {item.label}
              </Link>
            ))}
            <a
              href="tel:+917248491881"
              className="bg-brand-yellow text-brand-blue px-4 py-2 rounded-lg font-medium hover:bg-brand-yellow/90 flex items-center gap-2"
            >
              <Phone className="h-4 w-4" />
              Call Now
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="md:hidden text-white z-50">
            {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>

          {/* Mobile Menu */}
          <div
            className={`md:hidden fixed inset-0 bg-brand-blue transition-all duration-300 ${
              isMobileMenuOpen ? "opacity-100 visible" : "opacity-0 invisible"
            }`}
            style={{ top: headerHeight }}
          >
            <div className="container mx-auto px-4 py-6">
              <div className="flex flex-col space-y-4">
                {navItems.map((item, index) => (
                  <Link
                    key={index}
                    href={item.href}
                    className={`py-2 text-lg ${
                      isActive(item.href) ? "text-brand-yellow" : "text-white hover:text-brand-yellow"
                    }`}
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    {item.label}
                  </Link>
                ))}
                <a
                  href="tel:+917248491881"
                  className="bg-brand-yellow text-brand-blue px-6 py-3 rounded-lg text-lg font-medium hover:bg-brand-yellow/90 flex items-center justify-center gap-2 mt-4"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <Phone className="h-5 w-5" />
                  Call Now
                </a>
              </div>
            </div>
          </div>
        </nav>
      </div>
    </header>
  )
}

