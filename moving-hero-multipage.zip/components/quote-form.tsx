"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function QuoteForm() {
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "Sonuddn81@gmail.com", // Set default email
    fromCity: "",
    toCity: "",
    freightType: "",
  })

  const handleWhatsApp = () => {
    // Validate required fields
    if (!formData.name || !formData.phone || !formData.fromCity || !formData.toCity || !formData.freightType) {
      alert("Please fill in all required fields")
      return
    }

    // Format the message for WhatsApp
    const message = `*New Quote Request*
🏷️ Name: ${formData.name}
📱 Phone: ${formData.phone}
📧 Email: ${formData.email}
📍 From: ${formData.fromCity}
🎯 To: ${formData.toCity}
📦 Freight Type: ${formData.freightType}`

    // Encode the message for the URL
    const encodedMessage = encodeURIComponent(message)

    // Open WhatsApp with the pre-filled message
    window.open(`https://wa.me/917248491881?text=${encodedMessage}`, "_blank")

    // Reset form after sending
    setFormData({
      name: "",
      phone: "",
      email: "Sonuddn81@gmail.com",
      fromCity: "",
      toCity: "",
      freightType: "",
    })
  }

  return (
    <section id="quote-form" className="w-full bg-[#0a1f44] py-16 md:py-24 scroll-mt-[120px]">
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-2xl mx-auto">
          {/* Form Card */}
          <div className="bg-white rounded-lg shadow-xl overflow-hidden">
            <div className="p-8">
              <div className="text-center mb-8">
                <h3 className="text-lg font-medium text-gray-600 mb-2">Request a Call Back</h3>
                <h2 className="text-3xl font-bold text-brand-yellow">Get A Free Quote Today.</h2>
              </div>

              <div className="space-y-4">
                <Input
                  placeholder="Name*"
                  className="h-12"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />

                <Input
                  placeholder="Phone*"
                  type="tel"
                  className="h-12"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  required
                />

                <Input
                  placeholder="Email"
                  type="email"
                  className="h-12"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                />

                <Select
                  value={formData.freightType}
                  onValueChange={(value) => setFormData({ ...formData, freightType: value })}
                >
                  <SelectTrigger className="h-12">
                    <SelectValue placeholder="Freight type*" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Part Load">Part Load</SelectItem>
                    <SelectItem value="Full Load">Full Load</SelectItem>
                  </SelectContent>
                </Select>

                <Input
                  placeholder="City of Departure*"
                  className="h-12"
                  value={formData.fromCity}
                  onChange={(e) => setFormData({ ...formData, fromCity: e.target.value })}
                  required
                />

                <Input
                  placeholder="Delivery City*"
                  className="h-12"
                  value={formData.toCity}
                  onChange={(e) => setFormData({ ...formData, toCity: e.target.value })}
                  required
                />

                <Button
                  onClick={handleWhatsApp}
                  className="w-full h-12 bg-[#e84118] hover:bg-[#c23616] text-white font-medium text-lg"
                >
                  Request Submit
                </Button>
              </div>

              <p className="text-gray-500 text-center text-sm mt-6">* Required fields</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

