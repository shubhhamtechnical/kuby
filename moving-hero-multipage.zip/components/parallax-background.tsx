"use client"
import { motion, useScroll, useTransform } from "framer-motion"

export default function ParallaxBackground() {
  const { scrollY } = useScroll()
  const y1 = useTransform(scrollY, [0, 1000], [0, 300])
  const y2 = useTransform(scrollY, [0, 1000], [0, -300])

  return (
    <div className="fixed inset-0 -z-10 overflow-hidden">
      {/* Gradient Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-brand-blue via-brand-blue/50 to-brand-yellow/30" />

      {/* Parallax Shapes */}
      <motion.div style={{ y: y1 }} className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 rounded-full bg-brand-yellow/10 blur-3xl" />
        <div className="absolute top-3/4 right-1/4 w-96 h-96 rounded-full bg-brand-blue/10 blur-3xl" />
      </motion.div>

      <motion.div style={{ y: y2 }} className="absolute inset-0">
        <div className="absolute top-1/2 left-1/2 w-80 h-80 rounded-full bg-brand-yellow/20 blur-3xl" />
        <div className="absolute bottom-1/4 right-1/3 w-72 h-72 rounded-full bg-brand-blue/20 blur-3xl" />
      </motion.div>

      {/* Pattern Overlay */}
      <div className="absolute inset-0 opacity-5">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: "radial-gradient(circle at 1px 1px, currentColor 1px, transparent 0)",
            backgroundSize: "40px 40px",
          }}
        />
      </div>
    </div>
  )
}

