"use client"

import { Shield, Package, CreditCard, Truck, Users } from "lucide-react"
import { motion } from "framer-motion"

export default function ServicesSection() {
  const services = [
    {
      icon: Users,
      title: "Pan India Network",
      description: "Extensive network covering all major cities and states across India for seamless relocations.",
    },
    {
      icon: Shield,
      title: "Safe & Secure Moving",
      description: "Professional packing and handling with complete safety during interstate transportation.",
    },
    {
      icon: CreditCard,
      title: "Transparent Pricing",
      description: "Clear and competitive rates for both local and long-distance moves across India.",
    },
    {
      icon: Truck,
      title: "Nationwide Services",
      description: "Comprehensive moving solutions available throughout India, from metros to tier-2 cities.",
    },
    {
      icon: Package,
      title: "Customer Satisfaction",
      description: "Trusted by customers across India for reliable and professional moving services.",
    },
  ]

  return (
    <section id="services-section" className="w-full bg-[#FFF9E5] py-12 lg:py-24 scroll-mt-[120px]">
      <div className="w-full px-3 sm:container sm:mx-auto sm:px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center max-w-3xl mx-auto mb-12 lg:mb-16"
        >
          <div className="inline-block bg-brand-blue/10 text-brand-blue px-6 py-2 rounded-full mb-4">
            <span className="text-sm sm:text-base font-bold">Our Services</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-brand-yellow mb-4">What We Offer</h2>
          <p className="text-base sm:text-lg text-gray-600 px-3 sm:px-4">
            Professional moving services tailored to meet your specific needs
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8 max-w-6xl mx-auto">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group bg-white rounded-xl p-4 sm:p-6 lg:p-8 shadow-lg hover:shadow-xl transition-all duration-300"
            >
              <div className="flex flex-col items-center text-center space-y-3 sm:space-y-4">
                <div className="w-14 h-14 sm:w-16 sm:h-16 lg:w-20 lg:h-20 rounded-full bg-brand-blue/10 flex items-center justify-center group-hover:bg-brand-blue transition-colors duration-300">
                  <service.icon className="w-7 h-7 sm:w-8 sm:h-8 lg:w-10 lg:h-10 text-brand-blue group-hover:text-white transition-colors duration-300" />
                </div>
                <h3 className="text-lg sm:text-xl lg:text-2xl font-bold text-gray-900">{service.title}</h3>
                <p className="text-sm sm:text-base text-gray-600">{service.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

