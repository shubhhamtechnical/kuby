"use client"

import { gql, useQuery } from "@apollo/client"

const GET_EXAMPLE_DATA = gql`
  query GetExampleData {
    exampleField
  }
`

export default function ExampleQuery() {
  const { loading, error, data } = useQuery(GET_EXAMPLE_DATA)

  if (loading) return <p>Loading...</p>
  if (error) return <p>Error :(</p>

  return <div>{data.exampleField}</div>
}

