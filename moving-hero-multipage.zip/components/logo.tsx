export default function Logo() {
  return (
    <div className="flex items-center gap-2">
      <div className="flex flex-col">
        <span className="text-xl md:text-2xl font-bold tracking-wider text-white">VERMA</span>
        <span className="text-xs font-medium text-brand-yellow tracking-wide">PACKERS & MOVERS</span>
      </div>
    </div>
  )
}

