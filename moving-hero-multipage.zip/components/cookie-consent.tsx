"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"

export default function CookieConsent() {
  const [showConsent, setShowConsent] = useState(false)

  useEffect(() => {
    const consent = localStorage.getItem("cookieConsent")
    if (!consent) {
      setShowConsent(true)
    }
  }, [])

  const acceptCookies = () => {
    localStorage.setItem("cookieConsent", "true")
    setShowConsent(false)
  }

  const openCookieSettings = () => {
    console.log("Open cookie settings")
  }

  return (
    <AnimatePresence>
      {showConsent && (
        <motion.div
          initial={{ opacity: 0, y: 100 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 100 }}
          className="fixed bottom-0 left-0 right-0 z-50"
        >
          <div className="bg-[#0a1f44] p-4">
            <div className="container mx-auto">
              <div className="bg-white rounded-lg p-6 shadow-lg">
                <div className="max-w-4xl mx-auto">
                  <p className="text-base text-gray-700 font-medium mb-6">
                    By clicking "Accept All Cookies", you agree to the storing of cookies on your device to enhance site
                    navigation, analyze site usage, and assist in our marketing efforts.
                  </p>
                  <div className="flex flex-col gap-3 sm:flex-row sm:justify-end sm:items-center">
                    <Button
                      variant="link"
                      onClick={openCookieSettings}
                      className="text-brand-blue hover:text-brand-blue/80 font-medium text-base order-2 sm:order-1"
                    >
                      Cookies Settings
                    </Button>
                    <Button
                      onClick={acceptCookies}
                      className="w-full sm:w-auto bg-brand-blue hover:bg-brand-blue/90 text-white px-8 py-3 font-medium text-base order-1 sm:order-2"
                    >
                      Accept All Cookies
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

