"use client"

import { motion } from "framer-motion"
import { Truck, Package, Shield } from "lucide-react"

export default function FoundersMessage() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
    },
  }

  return (
    <section className="bg-gradient-to-br from-brand-blue via-brand-blue to-brand-yellow py-16 md:py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-brand-blue/90 via-brand-blue/80 to-brand-yellow/70" />

      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-64 h-64 bg-brand-yellow rounded-full opacity-10 -translate-x-1/2 -translate-y-1/2" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-brand-blue rounded-full opacity-10 translate-x-1/2 translate-y-1/2" />

      <div className="container mx-auto px-4 max-w-4xl relative z-10">
        <motion.div variants={containerVariants} initial="hidden" animate="visible" className="space-y-8">
          <motion.h2
            variants={itemVariants}
            className="text-3xl md:text-4xl font-bold text-center mb-8 text-brand-yellow"
          >
            Founder's Message
          </motion.h2>

          <motion.div
            variants={itemVariants}
            className="bg-white/10 backdrop-blur-md rounded-lg p-6 md:p-8 shadow-xl text-white"
          >
            <div className="space-y-6">
              <div>
                <h3 className="text-2xl font-bold mb-2">Verma Packers and Movers</h3>
                <p className="text-xl text-brand-yellow mb-4">"Transforming relocations into seamless experiences."</p>
              </div>
              <p className="text-lg md:text-xl mb-4">
                Our journey began in 2011, and over the past 15 years, we have built a trusted name in the moving
                industry. Through extensive experience in commercial truck driving and goods transportation across
                India, we gained in-depth knowledge of packing, loading, transportation, and delivery.
              </p>
              <p className="text-lg md:text-xl mb-4">
                We saw the challenges people faced while moving their belongings safely and efficiently. This inspired
                us to establish Verma Packers and Movers, with a vision to provide reliable, professional, and
                hassle-free relocation services.
              </p>
              <p className="text-lg md:text-xl mb-4">
                Today, with a dedicated team and modern logistics, we ensure that every move—whether big or small—is
                handled with care, precision, and commitment. Our goal is to make shifting stress-free for our customers
                by delivering safe, secure, and timely services.
              </p>
              <p className="text-lg md:text-xl">
                We are grateful to our customers for trusting us, and we look forward to serving many more in the
                future.
              </p>
            </div>
          </motion.div>

          <motion.div variants={itemVariants} className="grid md:grid-cols-3 gap-6 mt-12">
            <div className="bg-white/10 backdrop-blur-md rounded-lg p-6 text-center text-white">
              <Truck className="w-12 h-12 mx-auto mb-4 text-brand-yellow" />
              <h3 className="text-xl font-semibold mb-2">Experienced Team</h3>
              <p>Professional movers with years of experience</p>
            </div>
            <div className="bg-white/10 backdrop-blur-md rounded-lg p-6 text-center text-white">
              <Package className="w-12 h-12 mx-auto mb-4 text-brand-yellow" />
              <h3 className="text-xl font-semibold mb-2">Careful Handling</h3>
              <p>Your belongings are treated with utmost care</p>
            </div>
            <div className="bg-white/10 backdrop-blur-md rounded-lg p-6 text-center text-white">
              <Shield className="w-12 h-12 mx-auto mb-4 text-brand-yellow" />
              <h3 className="text-xl font-semibold mb-2">Secure Transport</h3>
              <p>Safe and timely delivery guaranteed</p>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}

