"use client"

import { useEffect, useState, useCallback } from "react"

// Move constants outside component to prevent recreating on each render
const START_DATE = new Date("2021-02-21").getTime()
const TOTAL_SHIFTINGS = 150
const MILLISECONDS_PER_DAY = 1000 * 60 * 60 * 24
const MILLISECONDS_PER_YEAR = MILLISECONDS_PER_DAY * 365

export function CountdownStats() {
  const [timeStats, setTimeStats] = useState({
    years: 0,
    days: 0,
    hours: 0,
  })
  const [shiftings, setShiftings] = useState(0)

  const calculateStats = useCallback(() => {
    const now = Date.now()
    const diff = now - START_DATE

    // Calculate time differences
    const years = Math.floor(diff / MILLISECONDS_PER_YEAR)
    const remainingMilliseconds = diff % MILLISECONDS_PER_YEAR
    const days = Math.floor(remainingMilliseconds / MILLISECONDS_PER_DAY)
    const hours = Math.floor((remainingMilliseconds % MILLISECONDS_PER_DAY) / (1000 * 60 * 60))

    // Calculate shiftings (proportional to time passed)
    const totalDays = Math.floor(diff / MILLISECONDS_PER_DAY)
    const currentShiftings = Math.min(TOTAL_SHIFTINGS, Math.floor((TOTAL_SHIFTINGS * totalDays) / (365 * 3)))

    return {
      timeStats: { years, days, hours },
      shiftings: currentShiftings,
    }
  }, [])

  useEffect(() => {
    // Initial calculation
    const initialStats = calculateStats()
    setTimeStats(initialStats.timeStats)
    setShiftings(initialStats.shiftings)

    // Update every hour
    const interval = setInterval(
      () => {
        const newStats = calculateStats()
        setTimeStats(newStats.timeStats)
        setShiftings(newStats.shiftings)
      },
      1000 * 60 * 60,
    )

    return () => clearInterval(interval)
  }, [calculateStats])

  return (
    <div className="grid grid-cols-2 gap-4">
      {/* Experience Counter */}
      <div className="bg-white rounded-lg p-4 text-center">
        <div className="text-xl md:text-2xl font-bold text-brand-blue mb-2">{timeStats.years}+ Years</div>
        <div className="text-sm text-gray-600 mb-2">Experience</div>
        <div className="text-xs text-gray-500">
          + {timeStats.days} days, {timeStats.hours} hours
        </div>
      </div>

      {/* Shiftings Counter */}
      <div className="bg-white rounded-lg p-4 text-center">
        <div className="text-xl md:text-2xl font-bold text-brand-blue mb-2">{shiftings}+ Done</div>
        <div className="text-sm text-gray-600 mb-2">Shiftings</div>
        <div className="text-xs text-gray-500">Out of {TOTAL_SHIFTINGS}+ total</div>
      </div>

      {/* Service Locations */}
      <div className="bg-white rounded-lg p-4 text-center">
        <div className="text-xl md:text-2xl font-bold text-brand-blue mb-2">15+</div>
        <div className="text-sm text-gray-600">Service Locations</div>
      </div>

      {/* Customer Support */}
      <div className="bg-white rounded-lg p-4 text-center">
        <div className="text-xl md:text-2xl font-bold text-brand-blue mb-2">24/7</div>
        <div className="text-sm text-gray-600">Customer Support</div>
      </div>
    </div>
  )
}

