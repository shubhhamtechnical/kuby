"use client"

import ImageLightbox from "./image-lightbox"

export default function GallerySection() {
  const images = [
    {
      src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG-20250221-WA0017.jpg-Lk5GV2Rrh8SgZJRb0fs7anIsLKxo35.jpeg",
      alt: "Verma Packers & Movers services overview",
    },
    {
      src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG-20250221-WA0018.jpg-HTnVQEaSSxbYSQyWyIGVJtNOspFwkp.jpeg",
      alt: "Verma Packers & Movers promotional image",
    },
    {
      src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG-20250221-WA0019.jpg-sR8InEinrwe48OQ46PzPWoYiPKtl7q.jpeg",
      alt: "Verma Packers & Movers Trust Badge",
    },
    {
      src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG-20250221-WA0020.jpg-DUOXB3DEgwsjKo8vlzbNF2Fy5Ql4xP.jpeg",
      alt: "Moving Services Illustration",
    },
    {
      src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG-20250221-WA0021.jpg-409bYQ8m91BZls8pz6VQaTid2nTlGc.jpeg",
      alt: "Moving Services Promotional Banner",
    },
    {
      src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG-20250221-WA0022.jpg-GXhbvD4vDPleQPqg7L1z76nN14Xjsp.jpeg",
      alt: "Verma Packers & Movers Website Logo",
    },
    {
      src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-02-21%20at%2015.05.17_6cff4ae2.jpg-49MbTofWhTm8zmE3fx2bnWjcAoBTbu.jpeg",
      alt: "Professional Moving Services Collage",
    },
    {
      src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/4342804.jpg-EK5o3ADUagHVKkvROvzvUkRlaq2dBb.jpeg",
      alt: "Professional movers loading furniture",
    },
  ]

  return (
    <section id="gallery" className="w-full bg-gray-50 py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-brand-yellow mb-4">Our Gallery</h2>
          <p className="text-gray-600">
            Explore our professional moving and packing services through our image gallery
          </p>
        </div>

        <ImageLightbox images={images} />
      </div>
    </section>
  )
}

