"use client"

import { motion, AnimatePresence } from "framer-motion"
import { X } from "lucide-react"

interface MobileMenuProps {
  isOpen: boolean
  onClose: () => void
  navItems: Array<{ id: string; label: string }>
  onNavItemClick: (id: string) => void
}

export default function MobileMenu({ isOpen, onClose, navItems, onNavItemClick }: MobileMenuProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 bg-brand-blue/95 backdrop-blur-sm lg:hidden"
        >
          <div className="container mx-auto px-4 py-6">
            <div className="flex justify-end mb-8">
              <button onClick={onClose} className="p-2 text-white hover:text-brand-yellow transition-colors">
                <X className="w-6 h-6" />
              </button>
            </div>

            <nav className="flex flex-col items-center space-y-6">
              {navItems.map((item) => (
                <motion.button
                  key={item.id}
                  onClick={() => {
                    onNavItemClick(item.id)
                    onClose()
                  }}
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  exit={{ x: 20, opacity: 0 }}
                  className="text-xl font-bold text-white hover:text-brand-yellow transition-colors"
                >
                  {item.label}
                </motion.button>
              ))}
              <motion.button
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: 20, opacity: 0 }}
                onClick={() => {
                  onNavItemClick("quote-form")
                  onClose()
                }}
                className="px-6 py-3 bg-brand-yellow text-brand-blue rounded-lg font-bold hover:bg-white transition-colors"
              >
                Get Quote
              </motion.button>
            </nav>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

