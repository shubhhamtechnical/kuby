"use client"

import { useEffect, useState } from "react"
import { motion, AnimatePresence } from "framer-motion"

export default function Preloader() {
  const [isLoading, setIsLoading] = useState(true)
  const [showContent, setShowContent] = useState(false)

  useEffect(() => {
    // Show content after a brief delay
    const contentTimer = setTimeout(() => {
      setShowContent(true)
    }, 500)

    // Hide preloader after loading time
    const loadingTimer = setTimeout(() => {
      setIsLoading(false)
    }, 2500)

    return () => {
      clearTimeout(contentTimer)
      clearTimeout(loadingTimer)
    }
  }, [])

  return (
    <AnimatePresence>
      {isLoading && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{
            opacity: 0,
            scale: 1.5,
            filter: "blur(10px)",
            transition: { duration: 0.8, ease: "easeInOut" },
          }}
          className="fixed inset-0 z-[9999] flex items-center justify-center bg-brand-blue overflow-hidden"
        >
          <div className="relative text-center">
            {/* Background Circles */}
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
              className="absolute inset-0 bg-brand-yellow/10 rounded-full blur-3xl"
              style={{ width: "300px", height: "300px", margin: "auto" }}
            />

            {/* Logo Container */}
            <motion.div
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{
                scale: [0.5, 1.1, 1],
                opacity: 1,
              }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="relative mb-8"
            >
              {/* Animated Logo */}
              <svg
                width="120"
                height="120"
                viewBox="0 0 48 48"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                className="mx-auto"
              >
                <motion.path
                  d="M24 4L44 24L24 44L4 24L24 4Z"
                  fill="#FDD500"
                  initial={{ pathLength: 0, scale: 0.8 }}
                  animate={{
                    pathLength: 1,
                    scale: 1,
                    transition: { duration: 1.5, ease: "easeInOut" },
                  }}
                />
                <motion.text
                  x="24"
                  y="32"
                  textAnchor="middle"
                  fill="#0372FF"
                  fontSize="24"
                  fontWeight="bold"
                  fontFamily="Arial"
                  initial={{ opacity: 0, scale: 0.5 }}
                  animate={{
                    opacity: 1,
                    scale: 1,
                    transition: { delay: 0.5, duration: 0.5 },
                  }}
                >
                  V
                </motion.text>
              </svg>
            </motion.div>

            {/* Text Content */}
            <AnimatePresence>
              {showContent && (
                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  exit={{ y: -20, opacity: 0 }}
                  transition={{ duration: 0.5 }}
                  className="relative"
                >
                  <motion.h2
                    className="text-3xl font-bold text-white mb-2"
                    initial={{ scale: 0.9 }}
                    animate={{ scale: 1 }}
                    transition={{ duration: 0.5, delay: 0.2 }}
                  >
                    Verma Packers & Movers
                  </motion.h2>
                  <motion.p
                    className="text-white/80"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.5, delay: 0.4 }}
                  >
                    Loading your experience...
                  </motion.p>

                  {/* Loading Bar */}
                  <motion.div
                    className="w-64 h-1 bg-white/20 rounded-full mt-8 mx-auto overflow-hidden"
                    initial={{ opacity: 0, width: 0 }}
                    animate={{ opacity: 1, width: "16rem" }}
                    transition={{ duration: 0.5, delay: 0.6 }}
                  >
                    <motion.div
                      className="h-full bg-brand-yellow"
                      initial={{ width: "0%" }}
                      animate={{ width: "100%" }}
                      transition={{
                        duration: 1.5,
                        ease: "easeInOut",
                        delay: 0.7,
                      }}
                    />
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Decorative Elements */}
            <motion.div
              className="absolute -z-10 inset-0 flex items-center justify-center"
              initial={{ rotate: 0 }}
              animate={{ rotate: 360 }}
              transition={{ duration: 8, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
            >
              <div className="w-32 h-32 border-t-2 border-brand-yellow/30 rounded-full" />
            </motion.div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

