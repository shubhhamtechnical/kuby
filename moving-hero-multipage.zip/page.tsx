import Navbar from "./navbar"
import Hero from "./hero"
import ServicesSection from "./services-section"
import ServicesImageSection from "./services-image-section"
import WhyChooseUs from "./why-choose-us"
import QuoteForm from "./quote-form"

export default function Page() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <ServicesSection />
        <ServicesImageSection />
        <WhyChooseUs />
        <QuoteForm />
      </main>
    </>
  )
}

