"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function QuoteForm() {
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    fromCity: "",
    toCity: "",
    freightType: "",
    message: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission
    console.log(formData)
  }

  return (
    <section className="w-full bg-brand-blue py-16 md:py-24">
      <div className="container mx-auto px-4 max-w-2xl">
        <div className="text-center space-y-4 mb-8">
          <h3 className="text-white text-xl">Request Call Back</h3>
          <h2 className="text-white text-4xl md:text-5xl font-bold">Get A Free Quote Today.</h2>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <Input
            placeholder="Name"
            className="bg-white h-12"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          />

          <Input
            placeholder="Phone no."
            type="tel"
            className="bg-white h-12"
            value={formData.phone}
            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
          />

          <Input
            placeholder="From city"
            className="bg-white h-12"
            value={formData.fromCity}
            onChange={(e) => setFormData({ ...formData, fromCity: e.target.value })}
          />

          <Input
            placeholder="To city"
            className="bg-white h-12"
            value={formData.toCity}
            onChange={(e) => setFormData({ ...formData, toCity: e.target.value })}
          />

          <Select onValueChange={(value) => setFormData({ ...formData, freightType: value })}>
            <SelectTrigger className="bg-white h-12">
              <SelectValue placeholder="Freight type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="household">Household Goods</SelectItem>
              <SelectItem value="commercial">Commercial Goods</SelectItem>
              <SelectItem value="vehicle">Vehicle Transport</SelectItem>
              <SelectItem value="office">Office Relocation</SelectItem>
            </SelectContent>
          </Select>

          <Textarea
            placeholder="Message"
            className="bg-white min-h-[150px]"
            value={formData.message}
            onChange={(e) => setFormData({ ...formData, message: e.target.value })}
          />

          <Button
            type="submit"
            className="w-full bg-brand-yellow text-brand-blue hover:bg-brand-yellow/90 h-12 text-lg font-semibold"
          >
            Request submit
          </Button>
        </form>

        <p className="text-brand-yellow text-center mt-8 text-lg italic">
          We used best quality packing materials for pack your expansive or valuable items.
        </p>
      </div>
    </section>
  )
}

