"use client"

import { Phone, Mail, Globe } from "lucide-react"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"

export default function PolicyClientPage() {
  return (
    <>
      <Navbar />
      <main className="min-h-screen bg-gray-50 dark:bg-gray-900 pt-36">
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-3xl mx-auto bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 md:p-8">
            <h1 className="text-3xl font-bold text-brand-blue dark:text-white mb-6">Privacy Policy</h1>

            <section className="mb-8">
              <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-200 mb-4">Information We Collect</h2>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                When you interact with Verma Packers & Movers, we may collect personal information such as your name,
                phone number, email address, postal address, and moving details. We may also gather technical
                information like IP addresses and website usage data.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-200 mb-4">
                How We Use Your Information
              </h2>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                We use this information to provide and manage our moving services, communicate with you about bookings
                and promotions, improve our website, and comply with legal obligations.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-200 mb-4">Data Security</h2>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                We take appropriate measures to protect your personal information from unauthorized access, loss, or
                misuse. Your data is handled securely.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-200 mb-4">Your Rights</h2>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                You have the right to access, update, or delete your personal information and opt-out of marketing
                communications at any time.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-200 mb-4">Contact Us</h2>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                If you have any questions about this Privacy Policy or how we handle your information, please contact
                us:
              </p>
              <div className="bg-gray-50 dark:bg-gray-700 p-6 rounded-lg">
                <h3 className="font-semibold text-gray-800 dark:text-gray-200 mb-4">Verma Packers & Movers</h3>
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <Phone className="w-5 h-5 text-brand-blue" />
                    <a href="tel:+917248491881" className="text-gray-600 dark:text-gray-400 hover:text-brand-blue">
                      +91 72-4849-1881
                    </a>
                  </div>
                  <div className="flex items-center gap-2">
                    <Mail className="w-5 h-5 text-brand-blue" />
                    <a
                      href="mailto:Sonuddn81@gmail.com"
                      className="text-gray-600 dark:text-gray-400 hover:text-brand-blue"
                    >
                      Sonuddn81@gmail.com
                    </a>
                  </div>
                  <div className="flex items-center gap-2">
                    <Globe className="w-5 h-5 text-brand-blue" />
                    <span className="text-gray-600 dark:text-gray-400">www.vermapackers.com</span>
                  </div>
                </div>
              </div>
            </section>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}

