import PolicyClientPage from "./client-page"
import Navbar from "@/components/navbar"

export default function PolicyPage() {
  return (
    <>
      <Navbar />
      <PolicyClientPage />
    </>
  )
}

