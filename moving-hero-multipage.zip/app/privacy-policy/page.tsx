import Navbar from "@/components/navbar"
import Footer from "@/components/footer"

export default function PrivacyPolicyPage() {
  return (
    <>
      <Navbar />
      <main className="bg-white py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto prose prose-lg">
            <h1 className="text-4xl font-bold text-brand-blue mb-8">Privacy Policy</h1>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-800 mb-4">Introduction</h2>
              <p className="text-gray-600 mb-4">
                At Verma Packers & Movers, we take your privacy seriously. This Privacy Policy explains how we collect,
                use, disclose, and safeguard your information when you use our services.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-800 mb-4">Information We Collect</h2>
              <ul className="list-disc pl-6 text-gray-600 space-y-2">
                <li>Personal identification information (Name, email address, phone number, etc.)</li>
                <li>Address and location information for pickup and delivery</li>
                <li>Payment information</li>
                <li>Inventory details of items being moved</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-800 mb-4">Contact Us</h2>
              <div className="bg-gray-50 p-6 rounded-lg">
                <p className="text-gray-600">Email: Sonuddn81@gmail.com</p>
                <p className="text-gray-600">Phone: +91 72-4849-1881</p>
                <p className="text-gray-600">Address: F-25 Transport Nagar, Dehradun (UK)</p>
              </div>
            </section>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}

