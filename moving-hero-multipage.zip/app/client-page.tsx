"use client"

import { useEffect } from "react"
import Hero from "@/components/hero"
import Navbar from "@/components/navbar"
import ServicesSection from "@/components/services-section"
import StatsSection from "@/components/stats-section"
import AboutSection from "@/components/about-section"
import PolicySection from "@/components/policy-section"
import QuoteForm from "@/components/quote-form"
import Footer from "@/components/footer"
import { Button } from "@/components/ui/button"
import { ChevronUp } from "lucide-react"
import Preloader from "@/components/preloader"
import WhyChooseUs from "@/components/why-choose-us"
import FoundersMessage from "@/components/founders-message"
import Blog from "@/components/Blog"

export default function ClientPage() {
  useEffect(() => {
    document.documentElement.style.scrollBehavior = "smooth"
    return () => {
      document.documentElement.style.scrollBehavior = "auto"
    }
  }, [])

  return (
    <>
      <Preloader />
      <Navbar />
      <main className="overflow-hidden">
        <Hero />
        <ServicesSection />
        <StatsSection />
        <AboutSection />
        <WhyChooseUs />
        <FoundersMessage />
        <PolicySection />
        <Blog />
        <QuoteForm />

        <Button
          className="fixed bottom-4 right-4 z-50 rounded-full bg-brand-blue text-white shadow-lg hover:bg-brand-blue/90"
          size="icon"
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
        >
          <ChevronUp className="h-6 w-6" />
        </Button>
      </main>
      <Footer />
    </>
  )
}

