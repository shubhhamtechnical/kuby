import ServicesSection from "@/components/services-section"
import ServicesImageSection from "@/components/services-image-section"
import WhyChooseUs from "@/components/why-choose-us"
import Footer from "@/components/footer"
import ParallaxBackground from "@/components/parallax-background"

export default function ServicesPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <ParallaxBackground />
      <main className="flex-1 pt-20">
        {/* Services Hero */}
        <section className="bg-brand-blue py-16 md:py-24">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-brand-yellow mb-6">Our Services</h1>
              <p className="text-white/90 text-lg md:text-xl">
                Professional moving and packing services across all major cities in India
              </p>
            </div>
          </div>
        </section>

        <ServicesSection />
        <ServicesImageSection />
        <WhyChooseUs />
      </main>
      <Footer />
    </div>
  )
}

