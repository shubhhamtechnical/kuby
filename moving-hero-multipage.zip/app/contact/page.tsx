import QuoteForm from "@/components/quote-form"
import TestimonialsSection from "@/components/testimonials-section"
import Footer from "@/components/footer"
import ParallaxBackground from "@/components/parallax-background"
import { Mail, MapPin, Phone } from "lucide-react"

export default function ContactPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <ParallaxBackground />
      <main className="flex-1 pt-20">
        {/* Contact Hero */}
        <section className="bg-brand-blue py-16 md:py-24">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-brand-yellow mb-6">Contact Us</h1>
              <p className="text-white/90 text-lg md:text-xl">
                Get in touch for professional moving services across India
              </p>
            </div>
          </div>
        </section>

        {/* Contact Info */}
        <section className="w-full bg-white py-16">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
              <div className="bg-gray-50 p-6 rounded-lg text-center">
                <Phone className="w-8 h-8 text-brand-blue mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Call Us</h3>
                <a href="tel:+917248491881" className="text-brand-blue hover:underline">
                  +91 72-4849-1881
                </a>
              </div>

              <div className="bg-gray-50 p-6 rounded-lg text-center">
                <Mail className="w-8 h-8 text-brand-blue mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Email Us</h3>
                <a href="mailto:Sonuddn81@gmail.com" className="text-brand-blue hover:underline">
                  Sonuddn81@gmail.com
                </a>
              </div>

              <div className="bg-gray-50 p-6 rounded-lg text-center">
                <MapPin className="w-8 h-8 text-brand-blue mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Visit Us</h3>
                <p className="text-gray-600">F-25 Transport Nagar, Dehradun (UK)</p>
              </div>
            </div>
          </div>
        </section>

        <QuoteForm />
        <TestimonialsSection />
      </main>
      <Footer />
    </div>
  )
}

