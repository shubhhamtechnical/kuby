import Hero from "@/components/hero"
import ServicesPreview from "@/components/services-preview"
import Footer from "@/components/footer"
import ParallaxBackground from "@/components/parallax-background"

export default function Page() {
  return (
    <div className="flex min-h-screen flex-col">
      <ParallaxBackground />
      <main className="flex-1">
        <Hero />
        <ServicesPreview />
      </main>
      <Footer />
    </div>
  )
}

