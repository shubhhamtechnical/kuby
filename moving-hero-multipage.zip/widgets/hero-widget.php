<?php
class Verma_Packers_Hero_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'verma_packers_hero';
    }

    public function get_title() {
        return __('Verma Packers Hero', 'verma-packers');
    }

    public function get_icon() {
        return 'eicon-banner';
    }

    public function get_categories() {
        return ['general'];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Content', 'verma-packers'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => __('Title', 'verma-packers'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Welcome to', 'verma-packers'),
            ]
        );

        $this->add_control(
            'subtitle',
            [
                'label' => __('Subtitle', 'verma-packers'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Pan India Moving Services', 'verma-packers'),
            ]
        );

        $this->add_control(
            'description',
            [
                'label' => __('Description', 'verma-packers'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('Your trusted partner for hassle-free relocation across India', 'verma-packers'),
            ]
        );

        $this->add_control(
            'video_url',
            [
                'label' => __('Background Video URL', 'verma-packers'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'https://www.youtube.com/embed/p10x4nxuA-s',
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <section id="home" class="relative w-full min-h-screen overflow-hidden bg-gray-900">
            <div class="absolute inset-4 md:inset-8 lg:inset-12">
                <div class="relative w-full h-full overflow-hidden rounded-xl shadow-2xl">
                    <iframe
                        src="<?php echo esc_url($settings['video_url']); ?>?autoplay=1&mute=1&controls=0&loop=1&playlist=p10x4nxuA-s&modestbranding=1&showinfo=0&rel=0&end=30"
                        allow="autoplay; encrypted-media"
                        allowfullscreen
                        class="absolute top-1/2 left-1/2 w-[calc(100%+100px)] h-[calc(100%+100px)] -translate-x-1/2 -translate-y-1/2 scale-110"
                        style="pointer-events: none;"
                    ></iframe>
                    <div class="absolute inset-0 bg-gradient-to-b from-black/50 via-black/30 to-black/50"></div>
                    <div class="absolute inset-0 pattern-dots opacity-20"></div>
                </div>
            </div>

            <div class="relative z-10 container mx-auto px-4 h-screen flex flex-col justify-center items-center text-center">
                <h1 class="mb-6">
                    <span class="block text-2xl md:text-3xl text-white/90 font-medium mb-2">
                        <?php echo esc_html($settings['title']); ?>
                    </span>
                    <span class="block text-4xl md:text-6xl font-bold text-white mb-2 gradient-text">
                        <?php echo esc_html($settings['subtitle']); ?>
                    </span>
                </h1>

                <p class="text-xl md:text-2xl text-white/90 max-w-2xl mb-8 drop-shadow-lg">
                    <?php echo esc_html($settings['description']); ?>
                </p>

                <div class="flex flex-col sm:flex-row gap-4 items-center">
                    <a href="tel:+917248491881" class="bg-brand-blue text-white px-6 py-3 rounded-lg text-lg font-medium shadow-lg hover:bg-brand-blue/90 transition-all duration-300 flex items-center justify-center">
                        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path></svg>
                        Call Now
                    </a>
                    <a href="#quote" class="bg-brand-yellow text-brand-blue hover:bg-brand-yellow/90 px-8 py-3 rounded-full text-lg font-medium shadow-lg hover:shadow-xl transition-all duration-300">
                        Get Quote
                    </a>
                </div>
            </div>
        </section>
        <?php
    }
}

