<footer>
    <!-- Add your footer content here -->
</footer>
<?php wp_footer(); ?>
</body>
</html>

