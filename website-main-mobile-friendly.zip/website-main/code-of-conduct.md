# Code Of Conduct

[KubeSimplify](https://kubesimplify.com) community follows the [CNCF Code of Conduct](https://github.com/cncf/foundation/blob/main/code-of-conduct.md).
