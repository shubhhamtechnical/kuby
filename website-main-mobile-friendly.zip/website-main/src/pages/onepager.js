import React, { useState } from 'react';

const OnePager = () => {
    const [activeSection, setActiveSection] = useState('home');

    const sections = {
        home: <div><h2>Welcome to Our Website</h2><p>Explore everything in one place.</p></div>,
        about: <div><h2>About Us</h2><p>We are a cloud-native community helping developers learn and grow.</p></div>,
        services: <div><h2>Our Services</h2><p>Workshops, training, and mentorship in the cloud-native space.</p></div>,
        collaboration: <div><h2>Collaborations</h2><p>We partner with organizations to spread cloud-native awareness.</p></div>,
        contact: <div><h2>Contact Us</h2><p>Get in touch through our <a href="https://kubesimplify.com/contact" target="_blank" rel="noopener noreferrer">contact page</a>.</p></div>
    };

    return (
        <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
            <h1 style={{ textAlign: 'center', color: '#007BFF' }}>One Page Website</h1>
            <nav style={{ textAlign: 'center', marginBottom: '20px' }}>
                <button onClick={() => setActiveSection('home')}>Home</button>
                <button onClick={() => setActiveSection('about')}>About</button>
                <button onClick={() => setActiveSection('services')}>Services</button>
                <button onClick={() => setActiveSection('collaboration')}>Collaborations</button>
                <button onClick={() => setActiveSection('contact')}>Contact</button>
                <a href="/custom-page" style={{ marginLeft: '10px', textDecoration: 'none', fontWeight: 'bold', color: '#FF5733' }}>Custom Page</a>
            </nav>
            <div style={{ textAlign: 'center', padding: '20px', border: '1px solid #ddd', borderRadius: '5px' }}>
                {sections[activeSection]}
            </div>
        </div>
    );
};

export default OnePager;
