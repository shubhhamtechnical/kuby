import React from 'react'
import LiveWorkshop from '../components/liveworkshop/LiveWorkshop'

const Workshops = () => {
  return (
    <>
        <LiveWorkshop />
    </>
  )
}

export default Workshops