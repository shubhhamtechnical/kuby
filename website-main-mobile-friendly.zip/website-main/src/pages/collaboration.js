import React from 'react';

const Collaboration = () => {
    return (
        <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
            <h1 style={{ textAlign: 'center', color: '#007BFF' }}>Our Collaborations</h1>
            <p style={{ textAlign: 'center', fontSize: '18px' }}>
                At KubeSimplify, we believe in the power of collaboration to drive innovation in the cloud-native space. 
                We are proud to partner with organizations and events that share our mission of making cloud-native technologies accessible to everyone.
            </p>

            <h2 style={{ marginTop: '30px', color: '#333' }}>Event Partnerships</h2>
            <p>
                KubeSimplify has partnered with industry-leading events to share knowledge and empower developers. 
                One of our major collaborations is with <a href="https://www.containerdays.io/containerdays-conference-2024/partners/" target="_blank" rel="noopener noreferrer">ContainerDays 2024</a>. 
                We contribute through workshops, presentations, and hands-on learning sessions.
            </p>

            <h2 style={{ marginTop: '30px', color: '#333' }}>Why We Collaborate?</h2>
            <ul>
                <li>To spread awareness about cloud-native technologies.</li>
                <li>To conduct workshops and training sessions.</li>
                <li>To bring together experts and learners in the cloud-native space.</li>
                <li>To support open-source initiatives and community-driven projects.</li>
            </ul>

            <h2 style={{ marginTop: '30px', color: '#333' }}>Become a Partner</h2>
            <p>
                If you are interested in collaborating with KubeSimplify, reach out to us via our official 
                <a href="https://kubesimplify.com/contact" target="_blank" rel="noopener noreferrer"> contact page</a>. 
                Let's build the future of cloud-native together!
            </p>
        </div>
    );
};

export default Collaboration;
