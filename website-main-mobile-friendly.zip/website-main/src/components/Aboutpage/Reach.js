import React from 'react'
import styles from './styles.module.css';
import VisitorsSection from './images/VisitorsSection.png';

const Reach = () => {
 return (
  // image
  <div className={styles.ap_cont_3}>
    <img src={VisitorsSection}  className={styles.ap_cont_3_picture} alt="Visitors"/> 
  </div>
)}
export default Reach